# @r3act/core

Private alpha installation artifact. This package is unpublished and its namespace is not reserved. See the repository README and final master plan for the supported native TSX subset and evidence limits.
