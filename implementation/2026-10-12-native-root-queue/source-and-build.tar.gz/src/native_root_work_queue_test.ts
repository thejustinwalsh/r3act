import { assertEquals, assertThrows } from "jsr:@std/assert";
import { createAsyncStore } from "./async_store_runtime.ts";
import {
  bindStatePropsAt,
  ComponentStateRoot,
  defineComponent,
  useEffectAt,
  useStateAt,
  useStoreAt,
} from "./component_state_runtime.ts";
import { NativeRootWorkQueue } from "./native_root_work_queue.ts";
import { jsx } from "./jsx_binding_runtime.ts";
import { type MemoryNode, MemoryVDOMHost } from "./vdom_snapshot_runtime.ts";

const text = (node: MemoryNode): string =>
  (node.text ?? "") + node.children.map(text).join("");
function harness(id: string, host = new MemoryVDOMHost()) {
  const container = host.createContainer();
  const root = new ComponentStateRoot(host, container, {
    rootId: id,
    scheduleCommit: () => {},
  });
  return {
    host,
    container,
    root,
    text: () => container.children.map(text).join(""),
  };
}

Deno.test("native queue coexists on one root and rebases reverse-ready store work", () => {
  const app = harness("queue-overlap");
  const store = createAsyncStore(
    1,
    (state: number, action: number) => state + action,
  );
  let update!: (value: number) => boolean;
  const View = defineComponent("queue-overlap-view", () => {
    const [n, set] = useStateAt("n", 0);
    update = set;
    return jsx(
      "output",
      { "data-local": bindStatePropsAt(["n"], ([n]) => n) },
      String(useStoreAt("store", store)),
    );
  }, { propOnlySites: ["n"] });
  const tree = jsx(View, {});
  app.root.mount(tree);
  const queue = new NativeRootWorkQueue();
  for (const id of ["slow", "fast"]) {
    store.beginTransition(id, [app.root.rootId]);
  }
  store.dispatch(10, { kind: "transition", transitionId: "slow" });
  store.dispatch(100, { kind: "transition", transitionId: "fast" });
  const slow = queue.enqueue({
    id: "slow",
    roots: [{ root: app.root, tree }],
    pending: ["ready"],
    transitions: ["slow"],
    finishTransitions: true,
  });
  const fast = queue.enqueue({
    id: "fast",
    roots: [{ root: app.root, tree }],
    pending: ["ready"],
    transitions: ["fast"],
    finishTransitions: true,
  });
  update(8);
  app.root.flush();
  fast.resolve("ready");
  assertEquals([app.text(), slow.status, fast.status], [
    "101",
    "pending",
    "committed",
  ]);
  slow.resolve("ready");
  assertEquals(app.text(), "111");
  assertEquals(app.container.children[0].props["data-local"], 8);
  update(9);
  app.root.flush();
  assertEquals(app.container.children[0].props["data-local"], 9);
  queue.dispose();
  app.root.dispose();
  assertEquals(store.diagnostics().roots, 0);
});

Deno.test("native group publishes two roots and two stores before observers or effects", () => {
  const left = harness("queue-group-left"),
    right = harness("queue-group-right");
  const a = createAsyncStore(1, (s: number, n: number) => s + n),
    b = createAsyncStore(10, (s: number, n: number) => s + n);
  const observations: string[][] = [];
  const observe = () =>
    observations.push([
      left.text(),
      right.text(),
      String(a.getStateForRoot(left.root.rootId)),
      String(b.getStateForRoot(right.root.rootId)),
    ]);
  const Probe = defineComponent("queue-group-probe", () => {
    useEffectAt("observe", () => {
      observe();
    });
    return jsx("i", {}, "ready");
  });
  const View = defineComponent(
    "queue-group-view",
    ({ show }: { show: boolean }) =>
      jsx(
        "div",
        {},
        `${useStoreAt("a", a)}:${useStoreAt("b", b)}`,
        show ? jsx(Probe, {}) : null,
      ),
  );
  left.root.mount(jsx(View, { show: false }));
  right.root.mount(jsx(View, { show: false }));
  const unsubs = [
    a.subscribe(left.root.rootId, observe),
    b.subscribe(right.root.rootId, observe),
  ];
  for (const store of [a, b]) {
    store.beginTransition("group", [left.root.rootId, right.root.rootId]);
  }
  a.dispatch(2, { kind: "transition", transitionId: "group" });
  b.dispatch(20, { kind: "transition", transitionId: "group" });
  observations.length = 0;
  const queue = new NativeRootWorkQueue();
  const handle = queue.enqueue({
    id: "group",
    roots: [{ root: left.root, tree: jsx(View, { show: true }) }, {
      root: right.root,
      tree: jsx(View, { show: true }),
    }],
    transitions: ["group", "group"],
    finishTransitions: true,
  });
  assertEquals(handle.status, "committed");
  assertEquals(observations.length, 4);
  for (const observation of observations) {
    assertEquals(observation, ["3:30ready", "3:30ready", "3", "30"]);
  }
  for (const unsub of unsubs) unsub();
  queue.dispose();
  left.root.dispose();
  right.root.dispose();
});

Deno.test("native disposal cancels pending included work and leaves unrelated root usable", () => {
  const a = harness("queue-detach-a"), b = harness("queue-detach-b");
  const queue = new NativeRootWorkQueue();
  const one = queue.enqueue({
    id: "one",
    roots: [{ root: a.root, tree: jsx("i", {}, "a") }],
    pending: ["ready"],
  });
  const two = queue.enqueue({
    id: "two",
    roots: [{ root: b.root, tree: jsx("i", {}, "b") }],
    pending: ["ready"],
  });
  a.root.dispose();
  assertEquals(one.status, "cancelled");
  two.resolve("ready");
  assertEquals(two.status, "committed");
  assertEquals(b.text(), "b");
  queue.dispose();
  b.root.dispose();
});

Deno.test("native queue group host failure poisons every native root", () => {
  class ThrowHost extends MemoryVDOMHost {
    override createElement(_tag: string): MemoryNode {
      throw undefined;
    }
  }
  const a = harness("queue-fail-a"),
    b = harness("queue-fail-b", new ThrowHost());
  const queue = new NativeRootWorkQueue();
  let effects = 0;
  const View = defineComponent("queue-fail-view", () => {
    useEffectAt("effect", () => {
      effects++;
    });
    return jsx("i", {}, "new");
  });
  const handle = queue.enqueue({
    id: "fail",
    roots: [{ root: a.root, tree: jsx(View, {}) }, {
      root: b.root,
      tree: jsx(View, {}),
    }],
  });
  assertEquals(handle.status, "failed");
  assertEquals(effects, 0);
  assertThrows(() => a.root.prepare(jsx("i", {}, "retry")));
  assertThrows(() => b.root.prepare(jsx("i", {}, "retry")));
  queue.dispose();
  a.root.dispose();
  b.root.dispose();
});

Deno.test("effect disposal detaches native queue after publication without leaking later work", () => {
  const app = harness("queue-effect-dispose");
  const queue = new NativeRootWorkQueue();
  const later = queue.enqueue({
    id: "later",
    roots: [{ root: app.root, tree: jsx("i", {}, "later") }],
    pending: ["ready"],
  });
  const View = defineComponent("queue-effect-dispose-view", () => {
    useEffectAt("dispose", () => app.root.dispose());
    return jsx("i", {}, "published");
  });
  const now = queue.enqueue({
    id: "now",
    roots: [{ root: app.root, tree: jsx(View, {}) }],
  });
  assertEquals(now.status, "committed");
  assertEquals(later.status, "cancelled");
  assertEquals(app.root.diagnostics().disposed, true);
  queue.dispose();
});
