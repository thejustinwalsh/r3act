import {
  type AnyAsyncStore,
  batchStorePublication,
} from "./async_store_runtime.ts";
import {
  ComponentStateRoot,
  type NativeRootCandidate,
} from "./component_state_runtime.ts";
import { type RuntimeNode } from "./jsx_binding_runtime.ts";
import {
  type RootWorkHandle,
  RootWorkQueue,
  type RootWorkSettled,
} from "./root_work_queue.ts";

type NativeRoot = ComponentStateRoot<any, any>;
type Candidate = NativeRootCandidate<any, any>;

export type NativeRootWork = {
  readonly id: string;
  readonly roots: readonly {
    readonly root: NativeRoot;
    readonly tree: RuntimeNode;
  }[];
  readonly pending?: readonly string[];
  readonly key?: string;
  /** Explicit store transition inclusion; owning the work does not own domain actions. */
  readonly transitions?: readonly string[];
  /** Finish the included store scopes after publication; defaults to false. */
  readonly finishTransitions?: boolean;
  readonly onSettled?: (resolution: RootWorkSettled) => void;
};

/**
 * Native owner roots wired to the overlapping publication queue. Resource/task
 * readiness remains explicit via handle.resolve(); this is not yet Suspense.
 * Canceling work never removes dispatched actions or cancels their providers.
 */
export class NativeRootWorkQueue {
  #queue: RootWorkQueue<Candidate>;
  #roots = new Map<string, { root: NativeRoot; unsubscribe: () => void }>();
  #detached = new Set<string>();
  #callDepth = 0;
  #disposed = false;

  constructor(
    options: { maxStaleRetries?: number; onError?: (error: unknown) => void } =
      {},
  ) {
    this.#queue = new RootWorkQueue(
      new Map(),
      options.maxStaleRetries ?? 2,
      options.onError,
    );
  }

  enqueue(work: NativeRootWork): RootWorkHandle {
    this.#assertActive();
    const entries = work.roots.map(({ root, tree }) => ({ root, tree }));
    const transitions = Object.freeze([...new Set(work.transitions ?? [])]);
    const finishTransitions = work.finishTransitions === true;
    if (transitions.some((id) => typeof id !== "string" || !id)) {
      throw new Error("Store transition IDs must be nonempty strings");
    }
    if (!entries.length) throw new Error("Native work requires roots");
    if (
      new Set(entries.map(({ root }) => root.rootId)).size !== entries.length
    ) {
      throw new Error("Native work cannot contain duplicate root IDs");
    }
    for (const { root } of entries) this.#attach(root);
    return this.#invoke(() => {
      const handle = this.#queue.enqueue({
        id: work.id,
        roots: entries.map(({ root }) => root.rootId),
        key: work.key,
        pending: work.pending,
        prepare: () => {
          const prepared: Candidate[] = [];
          try {
            for (const { root, tree } of entries) {
              prepared.push(root.prepare(tree, { transitions }));
            }
            return prepared.map((value) => ({
              rootId: value.rootId,
              baseVersion: value.baseVersion,
              targetVersion: value.targetVersion,
              value,
              validate: () => value.validate(),
            }));
          } catch (error) {
            for (const candidate of prepared) candidate.discard();
            throw error;
          }
        },
        discard: ({ value }) => value.discard(),
        commit: (candidates) => {
          try {
            for (const { value } of candidates) value.commitHost();
            for (const { value } of candidates) value.publish();
          } catch (error) {
            for (const { value } of candidates) value.failGroup(error);
            throw error;
          }
        },
        afterCommit: (candidates) => {
          const errors: unknown[] = [];
          // Root pointers and queue versions are already visible before any
          // store subscriber or lifecycle callback can run.
          const byStore = new Map<AnyAsyncStore, Map<string, string[]>>();
          for (const { value } of candidates) {
            for (const store of value.stores) {
              let byTransition = byStore.get(store);
              if (!byTransition) byStore.set(store, byTransition = new Map());
              for (const id of transitions) {
                if (
                  !store.hasTransition(id) ||
                  !store.transitionRoots(id).includes(value.rootId)
                ) continue;
                let roots = byTransition.get(id);
                if (!roots) byTransition.set(id, roots = []);
                roots.push(value.rootId);
              }
            }
          }
          try {
            batchStorePublication(() => {
              for (const [store, byTransition] of byStore) {
                for (const [id, roots] of byTransition) {
                  store.commitTransitionRoots(id, roots, {
                    finish: finishTransitions,
                  });
                }
              }
            });
          } catch (error) {
            errors.push(error);
          }
          for (const { value } of candidates) {
            try {
              value.runEffects();
            } catch (error) {
              errors.push(error);
            }
          }
          if (errors.length) {
            throw new AggregateError(
              errors,
              "Native post-publication callbacks failed",
            );
          }
        },
        onStale: () => {
          this.#syncVersions();
          return "retry";
        },
        onSettled: work.onSettled,
      });
      return {
        id: handle.id,
        get status() {
          return handle.status;
        },
        get resolution() {
          return handle.resolution;
        },
        resolve: (resourceId) => this.#invoke(() => handle.resolve(resourceId)),
        cancel: (reason) => this.#invoke(() => handle.cancel(reason)),
      };
    });
  }

  getVersion(root: NativeRoot): number {
    return this.#queue.getVersion(root.rootId);
  }

  /** Detach coordinator registrations; roots and action scopes remain caller-owned. */
  dispose(): void {
    if (this.#disposed) return;
    this.#disposed = true;
    for (const rootId of this.#roots.keys()) this.#detached.add(rootId);
    if (this.#callDepth === 0) this.#flushDetached();
  }

  #attach(root: NativeRoot): void {
    if (root.diagnostics().disposed) {
      throw new Error("Cannot attach a disposed native root");
    }
    const prior = this.#roots.get(root.rootId);
    if (prior) {
      if (prior.root !== root) {
        throw new Error(`Native root ID collision: ${root.rootId}`);
      }
      return;
    }
    this.#queue.attachRoot(root.rootId, root.publicationVersion);
    const unsubscribe = root.onDispose(() => {
      this.#detached.add(root.rootId);
      if (this.#callDepth === 0) this.#flushDetached();
    });
    this.#roots.set(root.rootId, { root, unsubscribe });
  }

  #syncVersions(): void {
    for (const [rootId, { root }] of this.#roots) {
      if (this.#detached.has(rootId)) continue;
      const current = this.#queue.getVersion(rootId);
      if (root.publicationVersion > current) {
        this.#queue.recordRootCommit(rootId, root.publicationVersion);
      }
    }
  }

  #invoke<T>(callback: () => T): T {
    this.#callDepth++;
    try {
      this.#syncVersions();
      return callback();
    } finally {
      this.#callDepth--;
      if (this.#callDepth === 0) this.#flushDetached();
    }
  }

  #flushDetached(): void {
    for (const rootId of this.#detached) {
      const registered = this.#roots.get(rootId);
      if (!registered) continue;
      this.#queue.detachRoot(rootId);
      registered.unsubscribe();
      this.#roots.delete(rootId);
    }
    this.#detached.clear();
  }

  #assertActive(): void {
    if (this.#disposed) throw new Error("Native work queue is disposed");
  }
}
