import { type ClosedNumericExpression } from "./closed_numeric_expression.ts";
import {
  closedDataArray, closedDataRecord, evaluateClosedHostValue, exactClosedFields,
  isClosedHostPrimitive,
} from "./closed_host_value.ts";
import {
  closedStoreHostInputPaths, closedStoreHostInputs, closedStoreHostValueCount,
  isNormalizedClosedStoreHostProgram,
  type ClosedStoreHostOutput, type ClosedStoreHostProgram,
} from "./closed_store_host_program.ts";
import {
  readOwnedClosedProjectionBatch, type AnyAsyncStore, type OwnedClosedProjectionRequest,
  type StoreRenderTransaction,
} from "./async_store_runtime.ts";
import {
  captureOwnedClosedWorldInputs, type OwnedClosedWorldInputCell,
  type OwnerStateWorld,
} from "./owner_state_world.ts";
import { snapshotScopedHostProp } from "./scoped_host_values.ts";
import type { ClosedHostOutputValue } from "./closed_host_value.ts";
import type { StorePropDelta } from "./vdom_snapshot_runtime.ts";

export type ClosedStoreDataExecution = Readonly<{
  schemaVersion: 1;
  kind: "owned-data";
  componentProgramId: string;
  moduleRevision: string;
}>;

type ExecutionFacts = Readonly<{
  host: ClosedStoreHostProgram;
  paths: readonly (readonly (readonly string[])[])[];
  stateSites: readonly string[];
  inputCount: number;
  valueCount: number;
  retainedChildren: boolean;
}>;
const associations = new WeakMap<object, ExecutionFacts>();

declare const normalizedExecutionBrand: unique symbol;
export type NormalizedClosedStoreDataExecution = ClosedStoreDataExecution & Readonly<{
  [normalizedExecutionBrand]: true;
}>;

const numericExpression = (value: ClosedNumericExpression): boolean => {
  switch (value.kind) {
    case "input": return true;
    case "literal": return typeof value.value === "number" && Number.isFinite(value.value);
    case "unary": return value.operator !== "!" && numericExpression(value.argument);
    case "binary": return !["==", "!=", "===", "!==", "<", "<=", ">", ">="].includes(
      value.operator,
    ) && numericExpression(value.left) && numericExpression(value.right);
    default: return false;
  }
};

const supportedHost = (host: ClosedStoreHostProgram): boolean => {
  if (host.schemaVersion === 4) return false;
  if (host.schemaVersion === 5) {
    if (host.host.tag !== "group" || host.host.children.length !== 0) return false;
    return host.host.props.some(([, value]) => numericExpression(value as ClosedNumericExpression)) &&
      host.host.props.every(([, value]) => value.kind === "literal"
        ? isClosedHostPrimitive(value.value)
        : numericExpression(value as ClosedNumericExpression));
  }
  return host.host.props.length > 0 && host.host.props.every(([, value]) =>
    numericExpression(value as ClosedNumericExpression));
};

/** Copy an explicit data marker and bind it privately to a normalized host program. */
export const normalizeClosedStoreDataExecution = (
  raw: unknown,
  host: ClosedStoreHostProgram,
): NormalizedClosedStoreDataExecution | null => {
  try {
    if (!isNormalizedClosedStoreHostProgram(host) || !supportedHost(host)) return null;
    const data = closedDataRecord(raw);
    if (!data || !exactClosedFields(data, [
      "schemaVersion", "kind", "componentProgramId", "moduleRevision",
    ]) || data.schemaVersion !== 1 || data.kind !== "owned-data" ||
      data.componentProgramId !== host.componentProgramId ||
      data.moduleRevision !== host.moduleRevision) return null;
    const normalized = Object.freeze({
      schemaVersion: 1 as const,
      kind: "owned-data" as const,
      componentProgramId: host.componentProgramId,
      moduleRevision: host.moduleRevision,
    });
    const inputs = closedStoreHostInputs(host);
    associations.set(normalized, Object.freeze({
      host,
      paths: Object.freeze(inputs.map((input) => closedStoreHostInputPaths(input))),
      stateSites: host.schemaVersion === 7 ? host.stateSites : Object.freeze([]),
      inputCount: inputs.length,
      valueCount: closedStoreHostValueCount(host),
      retainedChildren: host.schemaVersion === 5 || host.schemaVersion === 6 ||
        host.schemaVersion === 7,
    }));
    return normalized as NormalizedClosedStoreDataExecution;
  } catch {
    return null;
  }
};

/** Evaluate only privately associated, finite numeric inputs into candidate-owned props. */
export const evaluateClosedStoreDataExecution = (
  execution: NormalizedClosedStoreDataExecution,
  numericValues: readonly number[],
): ClosedStoreHostOutput | null => {
  try {
    const facts = typeof execution === "object" && execution !== null
      ? associations.get(execution) : undefined;
    if (!facts) return null;
    const values = closedDataArray(numericValues);
    if (!values || values.length !== facts.valueCount ||
      values.some((value) => typeof value !== "number" || !Number.isFinite(value))) return null;
    return evaluateOwnedProps(facts, values as number[]);
  } catch {
    return null;
  }
};

const evaluateOwnedProps = (
  facts: ExecutionFacts, values: readonly number[],
): ClosedStoreHostOutput | null => {
  const props: (readonly [string, string | number | boolean | null])[] = [];
  for (const [name, expression] of facts.host.host.props) {
    const value = evaluateClosedHostValue(expression, values);
    if (!isClosedHostPrimitive(value)) return null;
    props.push(Object.freeze([name, value] as const));
  }
  return Object.freeze(props);
};

const ownedScalarStorePropDeltas = new WeakSet<StorePropDelta>();

/** Identify a region constructed by the shared scalar output authority. */
export const isOwnedScalarStorePropDelta = (region: StorePropDelta): boolean =>
  ownedScalarStorePropDeltas.has(region);

const ownScalarRegionData = (input: unknown): Record<string, unknown> | null => {
  if (input === null || typeof input !== "object") return null;
  try {
    const prototype = Object.getPrototypeOf(input);
    if (prototype !== Object.prototype && prototype !== null) return null;
    const descriptors = Object.getOwnPropertyDescriptors(input);
    const keys = Reflect.ownKeys(descriptors);
    if (keys.length < 3 || keys.length > 5 ||
      keys.some((key) => typeof key !== "string" ||
        !["key", "tag", "props", "retainedChildren", "componentOwner", "children"]
          .includes(key)) ||
      !descriptors.key || !descriptors.tag || !descriptors.props) return null;
    const copy: Record<string, unknown> = Object.create(null);
    for (const key of keys as string[]) {
      const descriptor = descriptors[key];
      if (!descriptor || !("value" in descriptor)) return null;
      copy[key] = descriptor.value;
    }
    return copy;
  } catch { return null; }
};

const ownArray = (input: unknown, limit: number): readonly unknown[] | null => {
  if (!Array.isArray(input)) return null;
  try {
    if (Object.getPrototypeOf(input) !== Array.prototype) return null;
    const size = Object.getOwnPropertyDescriptor(input, "length")?.value;
    if (!Number.isSafeInteger(size) || size < 0 || size > limit) return null;
    const descriptors = Object.getOwnPropertyDescriptors(input) as unknown as
      Record<string, PropertyDescriptor>;
    const length = descriptors.length?.value;
    if (length !== size ||
      Reflect.ownKeys(descriptors).length !== length + 1) return null;
    const copy: unknown[] = [];
    for (let index = 0; index < length; index++) {
      const descriptor = descriptors[index];
      if (!descriptor || !("value" in descriptor)) return null;
      copy.push(descriptor.value);
    }
    return copy;
  } catch { return null; }
};

/** Copy a caller's scalar Store region into a privately owned immutable shape. */
export const createOwnedScalarStorePropDelta = (
  region: StorePropDelta,
): StorePropDelta | null => {
  const data = ownScalarRegionData(region);
  return data ? copyOwnedScalarRegion(data) : null;
};

const copyOwnedScalarRegion = (fields: Record<string, unknown>): StorePropDelta | null => {
  const { key, tag, props, retainedChildren, componentOwner, children } = fields;
  if (typeof key !== "string" || !key || typeof tag !== "string" || !tag ||
    !["div", "span", "output", "group", "mesh"].includes(tag) ||
    (Object.hasOwn(fields, "retainedChildren") !==
      Object.hasOwn(fields, "componentOwner")) ||
    (Object.hasOwn(fields, "children") && children === undefined) ||
    (retainedChildren !== undefined && retainedChildren !== true) ||
    (componentOwner !== undefined &&
      (retainedChildren !== true || typeof componentOwner !== "number" ||
        !Number.isSafeInteger(componentOwner))) ||
    (retainedChildren === true && (componentOwner === undefined ||
      children !== undefined))) return null;
  const rawProps = ownArray(props, 32);
  if (!rawProps || (!rawProps.length && children === undefined)) return null;
  const pairs: (readonly [string, ClosedHostOutputValue])[] = [];
  const names = new Set<string>();
  for (const rawPair of rawProps) {
    const pair = ownArray(rawPair, 2);
    if (!pair || pair.length !== 2 || typeof pair[0] !== "string" ||
      !pair[0] || pair[0] === "__proto__" || pair[0] === "prototype" ||
      pair[0] === "constructor" || pair[0] === "ref" ||
      /^on[A-Z]/.test(pair[0]) || names.has(pair[0])) return null;
    const value = pair[1];
    if (value !== null && typeof value !== "string" &&
      typeof value !== "boolean" &&
      !(typeof value === "number" && Number.isFinite(value))) return null;
    const captured = snapshotScopedHostProp(tag, pair[0], value);
    if (!captured.accepted || captured.value === undefined ||
      !Object.is(captured.value, value)) return null;
    names.add(pair[0]);
    pairs.push(Object.freeze([pair[0], value] as const));
  }
  if (children !== undefined) {
    const empty = ownArray(children, 0);
    if (!empty || empty.length !== 0) return null;
  }
  const copy: StorePropDelta = Object.freeze({ key, tag,
    props: Object.freeze(pairs),
    ...(retainedChildren === true ? { retainedChildren: true as const,
      componentOwner: componentOwner as number } : {}),
    ...(children === undefined ? {} : { children: Object.freeze([]) }),
  });
  ownedScalarStorePropDeltas.add(copy);
  return copy;
};

const createOwnedRegionFromExecution = (
  facts: ExecutionFacts, owner: number, hostKey: string,
  props: ClosedStoreHostOutput,
): StorePropDelta => {
  const region: StorePropDelta = Object.freeze({
    key: facts.retainedChildren ? hostKey : facts.host.host.key,
    tag: facts.host.host.tag,
    props,
    ...(facts.retainedChildren ? { retainedChildren: true as const,
      componentOwner: owner } : {}),
  });
  ownedScalarStorePropDeltas.add(region);
  return region;
};

export type OwnedClosedStoreOutputRequest = Readonly<{
  execution: NormalizedClosedStoreDataExecution;
  owner: number;
  hostKey: string;
  inputs: readonly Readonly<{ store: AnyAsyncStore; readerId: string }>[];
}>;

export type OwnedClosedStoreOutputRow = Readonly<{
  owner: number;
  lineage: readonly number[];
  cells: readonly OwnedClosedWorldInputCell[];
  region: StorePropDelta;
}>;

type NormalizedRequest = Readonly<{
  facts: ExecutionFacts;
  owner: number;
  hostKey: string;
  inputs: readonly Readonly<{ store: AnyAsyncStore; readerId: string }>[];
}>;

/** Enclose passive captures and finite evaluation for ordered owned scalar rows. */
export const prepareOwnedClosedStoreOutputs = (
  world: OwnerStateWorld,
  transaction: StoreRenderTransaction,
  orderedRequests: readonly OwnedClosedStoreOutputRequest[],
): { kind: "ready"; rows: readonly OwnedClosedStoreOutputRow[] } |
  { kind: "public-required" } | null => {
  try {
    const rawRequests = closedDataArray(orderedRequests, 65536);
    if (!rawRequests || rawRequests.length === 0) return null;
    const normalized: NormalizedRequest[] = [];
    for (const raw of rawRequests) {
      const request = closedDataRecord(raw);
      if (!request || !exactClosedFields(request,
        ["execution", "owner", "hostKey", "inputs"])) return null;
      const facts = typeof request.execution === "object" && request.execution !== null
        ? associations.get(request.execution) : undefined;
      if (!facts || !Number.isSafeInteger(request.owner) ||
        typeof request.hostKey !== "string" || !request.hostKey) return null;
      const rawInputs = closedDataArray(request.inputs, 8);
      if (!rawInputs || rawInputs.length !== facts.inputCount) return null;
      const inputs: { store: AnyAsyncStore; readerId: string }[] = [];
      for (const rawInput of rawInputs) {
        const input = closedDataRecord(rawInput);
        if (!input || !exactClosedFields(input, ["store", "readerId"]) ||
          typeof input.readerId !== "string" || !input.readerId ||
          typeof input.store !== "object" || input.store === null) return null;
        inputs.push({ store: input.store as AnyAsyncStore, readerId: input.readerId });
      }
      normalized.push({ facts, owner: request.owner as number,
        hostKey: request.hostKey, inputs });
    }
    const worldRows = captureOwnedClosedWorldInputs(world,
      normalized.map(({ owner, facts }) => ({ owner, sites: facts.stateSites })));
    if (!worldRows) return { kind: "public-required" };
    const projectionRequests: OwnedClosedProjectionRequest[] = [];
    for (const row of normalized) {
      for (let index = 0; index < row.inputs.length; index++) {
        projectionRequests.push({ ...row.inputs[index], paths: row.facts.paths[index] });
      }
    }
    const projections = readOwnedClosedProjectionBatch(transaction, projectionRequests);
    if (!projections) return { kind: "public-required" };
    const scratch: number[] = [];
    const rows: OwnedClosedStoreOutputRow[] = [];
    let projectionIndex = 0;
    for (let index = 0; index < normalized.length; index++) {
      const request = normalized[index];
      const worldRow = worldRows[index];
      if (!worldRow || worldRow.owner !== request.owner ||
        worldRow.cells.length !== request.facts.stateSites.length) return null;
      scratch.length = request.facts.valueCount;
      let cursor = 0;
      for (let input = 0; input < request.inputs.length; input++) {
        const values = projections[projectionIndex++];
        if (!values || values.length !== request.facts.paths[input].length) return null;
        for (const value of values) {
          if (typeof value !== "number" || !Number.isFinite(value)) return null;
          scratch[cursor++] = value;
        }
      }
      for (const cell of worldRow.cells) {
        if (typeof cell.value !== "number" || !Number.isFinite(cell.value)) return null;
        scratch[cursor++] = cell.value;
      }
      if (cursor !== scratch.length) return null;
      const props = evaluateOwnedProps(request.facts, scratch);
      if (!props) return null;
      rows.push(Object.freeze({ owner: request.owner, lineage: worldRow.lineage,
        cells: worldRow.cells,
        region: createOwnedRegionFromExecution(request.facts, request.owner,
          request.hostKey, props) }));
    }
    return Object.freeze({ kind: "ready" as const, rows: Object.freeze(rows) });
  } catch {
    return null;
  }
};
