# Public Three host (private alpha)

All authored native TSX requires `nativeModulePlugin()` from
`compiler/vite_native_plugin.ts`. It discovers native runtime imports and emits
owner/source plans and JavaScript. See `src/browser/native_three_host.tsx` for
an actual scene and `native-three-host.html` for its page.

## Root and ownership

```ts
import { Scene } from "three";
import { createWorld } from "./src/native_runtime_api.ts";
import { createThreeNativeRoot } from "./src/three_host.ts";

const scene = new Scene();
const world = createWorld();
const native = createThreeNativeRoot(scene, {
  rootOptions: { world, rootId: "my-scene" },
});
// In a compiled TSX module: native.root.mount(<MyScene />).
// Updates use ordinary JSX props and native state/store reads.
native.dispose();
```

The supplied Scene and renderer belong to the application. Root disposal releases
native owners, events, refs and host handles; full host disposal releases its
fallback assets as well. JSX-created geometry/material resources are owned and
disposed once. Resources passed in mesh args or primitive object props remain
borrowed. The caller disposes those assets when their shared lifetime ends.

Constructor `args`, primitive `object` and attachment identity are immutable for
a mounted element. Change its key to replace it. This deliberately differs from
R3F's automatic reconstruction. Resource children attach to geometry/material
(or the documented string `attach` property); replacement uses an attachment
stack so removing the previous child does not overwrite its replacement.

## Declarative frame props

Named native components can use numeric `useState` and ordinary intrinsic props
such as `rotation-y={phase * 0.42}`. Supported pure expressions compile to direct
writers. The workbench's KineticForm uses this path; its frame test asserts that
objects change while component render counts stay fixed. Unsupported expressions
may require an owner render. There is no blanket no-render promise.

Transform tuples/axes, material color/roughness/metalness/opacity, supported
Object3D fields and camera fields have explicit writers. Removed supported props
restore their captured defaults. Use the exported property registry as the exact
support inventory. Material arrays, arbitrary dashed paths, attachment callbacks,
and automatic constructor reconstruction are not supported.

## Extension seam

```ts
const native = createThreeNativeRoot(scene, {
  registry: {
    probeGeometry(args) { return new ProbeGeometry(Number(args[0])); },
  },
  propertyWriters: {
    "probe-mode"(handle, value) {
      if (handle.kind !== "resource" || !(handle.resource instanceof ProbeGeometry)) {
        throw new TypeError("probe-mode requires ProbeGeometry");
      }
      handle.resource.mode = value == null ? "default" : String(value);
    },
  },
});
```

Factories return Object3D, BufferGeometry or Material. Custom writers own their
value validation and removal/reset behavior. Registration does not require
private reconciler access or a kernel edit. The exact compiled extension fixture
is `compiler/three_host_extension_execution_test.mjs`.

Refs expose raw Three instances after native publication, before effects;
unchanged refs stay attached. Callback cleanup and object.current are supported.
Animation in the example uses props, not ref mutations.

## Events and limits

The host stores handlers on explicit object targets. Pointer dispatch/raycast
helpers deliver intersection data and can carry a native event; there is no
ancestor bubbling. Hover/capture/missed-event policy and R3F event parity are not
claimed. The application owns DOM event listeners and renderer/camera bootstrap.

Host exceptions fail publication terminally; arbitrary GPU/object side effects
cannot be rolled back. Shared mutable Three resources are shared physical state:
writing their material props affects every consumer. Different root projections
cannot independently display contradictory values through the same mutable
material. Clone or independently own materials for that use; this is not a
proof of async isolation for arbitrary shared GPU resources.

React component/library compatibility, packaging, general performance superiority
and long-term maintenance results remain separate gates.
