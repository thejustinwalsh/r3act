import type { Plugin } from "vite";
import { transformWithOxc } from "vite";
import { nativeModuleCompilerPlugin, nativeRuntimeModuleFromSource } from "./vite_native_module.ts";

type HookHandler = (this: any, ...args: any[]) => any;
type HookValue<T extends HookHandler> = T | { handler: T };

const callPluginHook = <T extends HookHandler>(
  hook: HookValue<T> | undefined,
  context: ThisParameterType<T>,
  ...args: Parameters<T>
): ReturnType<T> | undefined => {
  if (!hook) return undefined;
  const handler = typeof hook === "function" ? hook : hook.handler;
  return handler.apply(context, args);
};

/**
 * Compose native Rust analysis with module-local TS/JSX lowering.
 *
 * Native TSX opts in through imports from the supported native runtime API;
 * ordinary React TSX is left for the consumer's normal Vite/React pipeline.
 * The generated JSX factory import is local to compiled native modules, so
 * this plugin never changes project-wide JSX settings.
 */
export const nativeModulePlugin = (options: { root?: string; compilerRoot?: string } = {}): Plugin => {
  const compiler = nativeModuleCompilerPlugin(options);
  return {
    name: "native-module",
    enforce: "pre",
    configResolved(config) {
      callPluginHook(compiler.configResolved, this, config);
    },
    async transform(source, id) {
      if (!id.split("?", 1)[0].endsWith(".tsx")) return null;
      const compiled = await callPluginHook(compiler.transform, this, source, id);
      if (!compiled || typeof compiled === "string") return compiled ?? null;

      const runtimeModule = nativeRuntimeModuleFromSource(source);
      // Marker based asyncTask-only modules remain a supported migration path.
      // Without the public native runtime module there is no correct local
      // factory to import, so leave their JSX for the configured Vite pipeline.
      if (!runtimeModule) return compiled;
      // The native runtime exports the classic factory ABI (`jsx` and
      // `Fragment`). Keeping this import scoped to this source module avoids
      // changing JSX behavior in React modules in the same Vite project.
      let factory = "__nativeJsx";
      let suffix = 0;
      while (new RegExp(`\\b${factory}\\b`).test(`${source}\n${compiled.code}`)) {
        factory = `__nativeJsx${++suffix}`;
      }
      const loweredInput = `${compiled.code}\nimport * as ${factory} from ${JSON.stringify(runtimeModule)};\n`;
      const inputMap = typeof compiled.map === "string"
        ? JSON.parse(compiled.map) as object
        : compiled.map;
      return await transformWithOxc(
        loweredInput,
        id.split("?", 1)[0],
        {
          lang: "tsx",
          jsx: {
            runtime: "classic",
            pragma: `${factory}.jsx`,
            pragmaFrag: `${factory}.Fragment`,
          },
        },
        inputMap ?? undefined,
      );
    },
    configureServer: compiler.configureServer,
    closeBundle: compiler.closeBundle,
  };
};
