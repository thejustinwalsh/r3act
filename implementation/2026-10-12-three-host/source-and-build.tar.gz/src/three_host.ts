import {
  AmbientLight,
  BoxGeometry,
  BufferGeometry,
  Color,
  DirectionalLight,
  Euler,
  Group,
  Material,
  Mesh,
  MeshBasicMaterial,
  MeshStandardMaterial,
  Object3D,
  PerspectiveCamera,
  Raycaster,
  TorusGeometry,
  Vector3,
  type ColorRepresentation,
  type Intersection,
} from "three";
import {
  createNativeRoot,
  type NativeRootOptions,
  type VDOMHost,
} from "./native_runtime_api.ts";

export type ThreeParent = Object3D | ThreeHandle;

export type ThreeObjectHandle = {
  readonly kind: "object";
  readonly tag: string;
  readonly object: Object3D;
  readonly owned: boolean;
  readonly creationArgs: readonly unknown[];
  live: boolean;
  originalParent?: Object3D | null;
  originalIndex?: number;
};

export type ThreeResourceHandle = {
  readonly kind: "resource";
  readonly tag: string;
  readonly resource: BufferGeometry | Material;
  readonly resourceKind: "geometry" | "material";
  readonly owned: boolean;
  readonly creationArgs: readonly unknown[];
  readonly requestedAttachment?: string;
  live: boolean;
  attachment?: {
    readonly parent: Object3D;
    readonly property: string;
    readonly previous: unknown;
  };
};

export type ThreeHandle = ThreeObjectHandle | ThreeResourceHandle;

export type ThreeHostFactory = (
  args: readonly unknown[],
  props: Readonly<Record<string, unknown>>,
) => Object3D | BufferGeometry | Material;

export type ThreeHostFactoryRegistry = Readonly<Record<string, ThreeHostFactory>>;

export type ThreePropertyWriter = (
  handle: ThreeHandle,
  value: unknown,
  previous: unknown,
) => void;

export type ThreeHostPropertyRegistry = Readonly<Record<string, ThreePropertyWriter>>;

export interface ThreeHostDiagnostics {
  readonly createdResources: number;
  readonly disposedResources: number;
  readonly liveResources: number;
  readonly liveHandles: number;
  readonly eventRegistrations: number;
}

export interface ThreeHost extends VDOMHost<ThreeHandle, ThreeParent> {
  readonly diagnostics: ThreeHostDiagnostics;
  dispatchPointerEvent(
    target: Object3D | ThreeObjectHandle,
    type: string,
    intersection?: Intersection<Object3D>,
    nativeEvent?: Event,
  ): boolean;
  dispose(handle: ThreeHandle): void;
  dispose(): void;
  getPublicInstance(handle: ThreeHandle): Object3D | BufferGeometry | Material;
}

export interface ThreeHostOptions {
  readonly registry?: ThreeHostFactoryRegistry;
  readonly propertyWriters?: ThreeHostPropertyRegistry;
}

interface AttachmentState {
  readonly baseValue: unknown;
  readonly handles: ThreeResourceHandle[];
}

export interface NativeThreePointerEvent {
  readonly type: string;
  readonly target: Object3D;
  readonly object: Object3D;
  readonly intersection?: Intersection<Object3D>;
  readonly nativeEvent?: Event;
  readonly point?: Intersection<Object3D>["point"];
  readonly distance?: number;
  readonly face?: Intersection<Object3D>["face"];
  readonly uv?: Intersection<Object3D>["uv"];
  readonly instanceId?: number;
}

const defaultFactories: Record<string, ThreeHostFactory> = {
  group: () => new Group(),
  perspectiveCamera: (args) => new PerspectiveCamera(
    args[0] as number | undefined,
    args[1] as number | undefined,
    args[2] as number | undefined,
    args[3] as number | undefined,
  ),
  ambientLight: (args) => new AmbientLight(
    args[0] as ColorRepresentation | undefined,
    args[1] as number | undefined,
  ),
  directionalLight: (args) => new DirectionalLight(
    args[0] as ColorRepresentation | undefined,
    args[1] as number | undefined,
  ),
  boxGeometry: (args) => new BoxGeometry(
    args[0] as number | undefined,
    args[1] as number | undefined,
    args[2] as number | undefined,
    args[3] as number | undefined,
    args[4] as number | undefined,
    args[5] as number | undefined,
  ),
  torusGeometry: (args) => new TorusGeometry(
    args[0] as number | undefined,
    args[1] as number | undefined,
    args[2] as number | undefined,
    args[3] as number | undefined,
    args[4] as number | undefined,
  ),
  meshStandardMaterial: (args) => new MeshStandardMaterial(
    (args[0] ?? {}) as ConstructorParameters<typeof MeshStandardMaterial>[0],
  ),
};

const defaultPropertyWriters: Record<string, ThreePropertyWriter> = {
  args: (handle, value, previous) => {
    if (previous !== undefined && !sameArgs(value, previous)) {
      throw new Error(
        `Three args for <${handle.tag}> are immutable; change the element key to replace the object.`,
      );
    }
    if (previous === undefined && !sameArgs(value, handle.creationArgs)) {
      throw new Error(`Three args for <${handle.tag}> changed during creation.`);
    }
  },
  attach: (handle, value, previous) => {
    if (previous !== undefined && value !== previous) {
      throw new Error(
        `Three attach for <${handle.tag}> is immutable; change the element key to replace the attachment.`,
      );
    }
  },
  object: (handle, value, previous) => {
    if (previous !== undefined && value !== previous) {
      throw new Error(
        "Three <primitive> object is immutable; change the element key to replace it.",
      );
    }
    const expected = handle.kind === "object" ? handle.object : handle.resource;
    if (value !== expected) {
      throw new Error("Three <primitive> object prop must remain the same borrowed Three object.");
    }
  },
  position: (handle, value) => setVector(handle, "position", value),
  rotation: (handle, value) => setVector(handle, "rotation", value),
  scale: (handle, value) => setVector(handle, "scale", value),
  "position-x": (handle, value) => setAxis(handle, "position", "x", value),
  "position-y": (handle, value) => setAxis(handle, "position", "y", value),
  "position-z": (handle, value) => setAxis(handle, "position", "z", value),
  "rotation-x": (handle, value) => setAxis(handle, "rotation", "x", value),
  "rotation-y": (handle, value) => setAxis(handle, "rotation", "y", value),
  "rotation-z": (handle, value) => setAxis(handle, "rotation", "z", value),
  "scale-x": (handle, value) => setAxis(handle, "scale", "x", value),
  "scale-y": (handle, value) => setAxis(handle, "scale", "y", value),
  "scale-z": (handle, value) => setAxis(handle, "scale", "z", value),
  "material-roughness": (handle, value) => setMaterialProp(handle, "roughness", value),
  "material-metalness": (handle, value) => setMaterialProp(handle, "metalness", value),
  "material-opacity": (handle, value) => setMaterialProp(handle, "opacity", value),
  "material-transparent": (handle, value) => setMaterialProp(handle, "transparent", value),
  "material-color": (handle, value) => setColor(handle, "material", value),
  color: (handle, value) => setColor(handle, "color", value),
  opacity: (handle, value) => setMaterialProp(handle, "opacity", value),
  transparent: (handle, value) => setMaterialProp(handle, "transparent", value),
  roughness: (handle, value) => setMaterialProp(handle, "roughness", value),
  metalness: (handle, value) => setMaterialProp(handle, "metalness", value),
  intensity: (handle, value) => setObjectOrMaterialProp(handle, "intensity", value),
  visible: (handle, value) => setObjectProp(handle, "visible", value),
  castShadow: (handle, value) => setObjectProp(handle, "castShadow", value),
  receiveShadow: (handle, value) => setObjectProp(handle, "receiveShadow", value),
  name: (handle, value) => setObjectProp(handle, "name", value),
  fov: (handle, value) => setObjectProp(handle, "fov", value),
  near: (handle, value) => setObjectProp(handle, "near", value),
  far: (handle, value) => setObjectProp(handle, "far", value),
  userData: (handle, value) => setObjectProp(handle, "userData", value),
};

const originalPropValues = new WeakMap<object, Map<string, unknown>>();

const copyOriginalValue = (value: unknown): unknown => {
  if (value && typeof value === "object" && "clone" in value && typeof value.clone === "function") {
    return value.clone();
  }
  return value;
};

const captureOriginalValue = (target: object, name: string, current: unknown) => {
  let values = originalPropValues.get(target);
  if (!values) {
    values = new Map();
    originalPropValues.set(target, values);
  }
  if (!values.has(name)) values.set(name, copyOriginalValue(current));
  return values.get(name);
};

const originalValueFor = (target: object, name: string, current: unknown) =>
  originalPropValues.get(target)?.get(name) ?? captureOriginalValue(target, name, current);

export const threeHostFactoryRegistry: ThreeHostFactoryRegistry = Object.freeze({
  ...defaultFactories,
});

export const threeHostPropertyRegistry: ThreeHostPropertyRegistry = Object.freeze({
  ...defaultPropertyWriters,
});

const sameArgs = (next: unknown, previous: unknown): boolean =>
  Array.isArray(next) && Array.isArray(previous) && next.length === previous.length &&
  next.every((value, index) => Object.is(value, previous[index]));

const objectFor = (handle: ThreeHandle): Object3D => {
  if (handle.kind !== "object") {
    throw new Error(`Three <${handle.tag}> is a resource and cannot contain children.`);
  }
  return handle.object;
};

const objectForParent = (parent: ThreeParent): Object3D =>
  parent instanceof Object3D ? parent : objectFor(parent);

const resourceType = (value: Object3D | BufferGeometry | Material): "object" | "geometry" | "material" => {
  if (value instanceof Object3D) return "object";
  if (value instanceof BufferGeometry) return "geometry";
  if (value instanceof Material) return "material";
  throw new TypeError("Three host factory must return an Object3D, BufferGeometry, or Material.");
};

const setObjectProp = (handle: ThreeHandle, name: string, value: unknown) => {
  if (handle.kind !== "object" || !(name in handle.object)) {
    throw new Error(`Three <${handle.tag}> does not support property "${name}".`);
  }
  const target = handle.object as unknown as Record<string, unknown>;
  const initial = captureOriginalValue(handle.object, name, target[name]);
  target[name] = value == null ? initial : value;
  if (handle.object instanceof PerspectiveCamera && ["fov", "near", "far"].includes(name)) {
    handle.object.updateProjectionMatrix();
  }
};

const setObjectOrMaterialProp = (handle: ThreeHandle, name: string, value: unknown) => {
  if (handle.kind === "object" && name in handle.object) {
    setObjectProp(handle, name, value);
  } else setMaterialProp(handle, name, value);
};

const materialFor = (handle: ThreeHandle): Material => {
  if (handle.kind === "resource" && handle.resource instanceof Material) return handle.resource;
  if (handle.kind === "object" && handle.object instanceof Mesh) {
    if (Array.isArray(handle.object.material)) {
      throw new Error("Three material arrays are not supported by this host yet.");
    }
    return handle.object.material;
  }
  throw new Error(`Three <${handle.tag}> has no material to write.`);
};

  const setMaterialProp = (handle: ThreeHandle, name: string, value: unknown) => {
  const material = materialFor(handle) as unknown as Record<string, unknown>;
  if (!(name in material)) throw new Error(`Three material does not support property "${name}".`);
  const target = materialFor(handle);
  const current = material[name];
  const initial = captureOriginalValue(target, name, current);
  if (name === "color") {
    const color = current as Color;
    if (!(color instanceof Color)) throw new Error("Three material color is not writable.");
    if (value == null) color.copy(initial as Color);
    else color.set(value as ColorRepresentation);
    return;
  }
  material[name] = value == null ? initial : value;
};

const setColor = (handle: ThreeHandle, name: "color" | "material", value: unknown) => {
  const target = name === "material"
    ? materialFor(handle) as unknown as Record<string, unknown>
    : handle.kind === "object" && "color" in handle.object
    ? handle.object as unknown as Record<string, unknown>
    : materialFor(handle) as unknown as Record<string, unknown>;
  const resetTarget = name === "material" || !(handle.kind === "object" && "color" in handle.object)
    ? materialFor(handle)
    : handle.object;
  const color = target.color as Color | undefined;
  if (!(color instanceof Color)) throw new Error(`Three <${handle.tag}> does not have a writable color.`);
  const initial = captureOriginalValue(resetTarget, "color", color);
  if (value == null) color.copy(initial as Color);
  else color.set(value as ColorRepresentation);
};

const setVector = (handle: ThreeHandle, name: "position" | "rotation" | "scale", value: unknown) => {
  if (handle.kind !== "object") throw new Error(`Three <${handle.tag}> has no ${name} vector.`);
  const target = handle.object[name];
  const initial = captureOriginalValue(handle.object, name, target);
  if (value == null) {
    if (name === "rotation") handle.object.rotation.copy(initial as Euler);
    else handle.object[name].copy(initial as Vector3);
    return;
  }
  if (!Array.isArray(value) || value.length !== 3 || value.some((entry) => typeof entry !== "number")) {
    throw new TypeError(`Three ${name} expects a three-number tuple.`);
  }
  target.set(value[0], value[1], value[2]);
};

const setAxis = (handle: ThreeHandle, name: "position" | "rotation" | "scale", axis: "x" | "y" | "z", value: unknown) => {
  if (handle.kind !== "object") {
    throw new TypeError(`Three ${name}-${axis} expects an Object3D target.`);
  }
  const initial = captureOriginalValue(handle.object, `${name}-${axis}`, handle.object[name][axis]);
  if (value == null) {
    handle.object[name][axis] = initial as number;
    return;
  }
  if (typeof value !== "number") {
    throw new TypeError(`Three ${name}-${axis} expects a numeric Object3D property.`);
  }
  handle.object[name][axis] = value;
};

const eventTypeForProp = (name: string): string | undefined => {
  const match = /^onPointer(Down|Up|Move|Enter|Leave|Over|Out|Cancel)$/.exec(name);
  return match ? `pointer${match[1].toLowerCase()}` : undefined;
};

export const nativePointerEvent = (
  type: string,
  intersection?: Intersection<Object3D>,
  nativeEvent?: Event,
): NativeThreePointerEvent => {
  if (!type.startsWith("pointer")) {
    throw new TypeError(`Unsupported Three native event type "${type}".`);
  }
  const object = intersection?.object;
  if (!object) throw new TypeError("A Three pointer event requires an intersection with an Object3D.");
  return {
    type,
    target: object,
    object,
    intersection,
    nativeEvent,
    point: intersection.point,
    distance: intersection.distance,
    face: intersection.face,
    uv: intersection.uv,
    instanceId: intersection.instanceId,
  };
};

export function createThreeHost(options: ThreeHostOptions = {}): ThreeHost {
  const factories = { ...threeHostFactoryRegistry, ...options.registry };
  const propertyWriters = { ...threeHostPropertyRegistry, ...options.propertyWriters };
  const objectHandles = new WeakMap<Object3D, ThreeObjectHandle>();
  const eventHandlers = new Map<Object3D, Map<string, (event: NativeThreePointerEvent) => void>>();
  const handles = new Set<ThreeHandle>();
  const liveResources = new Set<BufferGeometry | Material>();
  const disposedResources = new WeakSet<BufferGeometry | Material>();
  const pendingMaterialProps = new WeakMap<Object3D, Map<string, unknown>>();
  const attachmentStates = new WeakMap<Object3D, Map<string, AttachmentState>>();
  let createdResourceCount = 0;
  let disposedResourceCount = 0;
  let hostDisposed = false;
  const fallbackGeometry = new BufferGeometry();
  const fallbackMaterial = new MeshBasicMaterial();

  const ownResource = <T extends BufferGeometry | Material>(resource: T) => {
    liveResources.add(resource);
    createdResourceCount++;
    return resource;
  };

  const disposeResource = (resource: BufferGeometry | Material) => {
    if (disposedResources.has(resource)) return;
    disposedResources.add(resource);
    if (liveResources.delete(resource)) disposedResourceCount++;
    resource.dispose();
  };

  const removeEvents = (object: Object3D) => {
    eventHandlers.delete(object);
  };

  const restoreBorrowedObject = (handle: ThreeObjectHandle) => {
    if (!handle.originalParent) return;
    handle.originalParent.add(handle.object);
    const current = handle.originalParent.children.indexOf(handle.object);
    if (current >= 0) handle.originalParent.children.splice(current, 1);
    const index = Math.max(0, Math.min(handle.originalIndex ?? 0, handle.originalParent.children.length));
    handle.originalParent.children.splice(index, 0, handle.object);
  };

  const releaseHandle = (handle: ThreeHandle, errors: unknown[] = []) => {
    if (!handle.live) return;
    handle.live = false;
    handles.delete(handle);
    try {
      if (handle.kind === "object") {
        removeEvents(handle.object);
        if (!handle.owned) restoreBorrowedObject(handle);
      } else {
        restoreAttachment(handle);
        if (handle.owned) disposeResource(handle.resource);
      }
    } catch (error) {
      errors.push(error);
    }
  };

  const restoreAttachment = (handle: ThreeResourceHandle) => {
    const attachment = handle.attachment;
    if (!attachment) return;
    const parent = attachment.parent as unknown as Record<string, unknown>;
    const propertyStates = attachmentStates.get(attachment.parent);
    const state = propertyStates?.get(attachment.property);
    const isCurrent = parent[attachment.property] === handle.resource;
    if (state) {
      const index = state.handles.indexOf(handle);
      if (index >= 0) state.handles.splice(index, 1);
      if (isCurrent) {
        const replacement = state.handles.at(-1);
        parent[attachment.property] = replacement?.resource ?? state.baseValue;
      }
      if (state.handles.length === 0) propertyStates?.delete(attachment.property);
    } else if (isCurrent) {
      parent[attachment.property] = attachment.previous;
    }
    handle.attachment = undefined;
  };

  const attachResource = (parent: Object3D, handle: ThreeResourceHandle, requested?: string) => {
    if (handle.attachment?.parent === parent) return;
    restoreAttachment(handle);
    const property = requested ?? handle.resourceKind;
    if (!(property in parent)) {
      throw new Error(`Cannot attach Three ${handle.resourceKind} to Object3D property "${property}".`);
    }
    const parentProperties = parent as unknown as Record<string, unknown>;
    const previous = parentProperties[property];
    if (property === "material" && Array.isArray(previous)) {
      throw new Error("Three material arrays are not supported by this host yet.");
    }
    const propertyStates = attachmentStates.get(parent) ?? new Map<string, AttachmentState>();
    let state = propertyStates.get(property);
    if (!state) {
      state = { baseValue: previous, handles: [] };
      propertyStates.set(property, state);
      attachmentStates.set(parent, propertyStates);
    }
    state.handles.push(handle);
    parentProperties[property] = handle.resource;
    handle.attachment = { parent, property, previous };
    if (property === "material" && handle.resource instanceof Material) {
      const pending = pendingMaterialProps.get(parent);
      if (pending) {
        const parentHandle = objectHandles.get(parent);
        if (!parentHandle) throw new Error("Three material attachment has no owning Object3D handle.");
        for (const [name, value] of pending) {
          const writer = propertyWriters[`material-${name}`];
          if (!writer) throw new Error(`Three material does not support property "${name}".`);
          writer(parentHandle, value, undefined);
        }
      }
    }
  };

  const host: ThreeHost = {
    get diagnostics() {
      let eventRegistrations = 0;
      for (const handlers of eventHandlers.values()) eventRegistrations += handlers.size;
      return Object.freeze({
        createdResources: createdResourceCount,
        disposedResources: disposedResourceCount,
        liveResources: liveResources.size,
        liveHandles: handles.size,
        eventRegistrations,
      });
    },
    createElement(tag, parent, creationProps = {}) {
      if (hostDisposed) throw new Error("Three host is disposed.");
      const args = Array.isArray(creationProps.args) ? creationProps.args : [];
      let produced: Object3D | BufferGeometry | Material;
      let owned = tag !== "primitive";
      if (tag === "primitive") {
        const primitive = creationProps.object;
        if (!(primitive instanceof Object3D || primitive instanceof BufferGeometry || primitive instanceof Material)) {
          throw new TypeError("Three <primitive> requires an Object3D, BufferGeometry, or Material object prop.");
        }
        produced = primitive;
        owned = false;
      } else if (tag === "mesh") {
        if (args.length > 2 || (args[0] !== undefined && !(args[0] instanceof BufferGeometry)) ||
          (args[1] !== undefined && !(args[1] instanceof Material))) {
          throw new TypeError("Three <mesh> args must be an optional [BufferGeometry, Material] tuple.");
        }
        const geometry = args[0] instanceof BufferGeometry ? args[0] : fallbackGeometry;
        const material = args[1] instanceof Material ? args[1] : fallbackMaterial;
        produced = new Mesh(geometry, material);
      } else {
        const factory = factories[tag];
        if (!factory) throw new Error(`Unsupported Three host tag <${tag}>.`);
        produced = factory(args, creationProps);
      }
      const kind = resourceType(produced);
      const handle: ThreeHandle = kind === "object"
        ? {
          kind,
          tag,
          object: produced as Object3D,
          owned,
          creationArgs: args,
          live: true,
          ...(tag === "primitive"
            ? {
              originalParent: (produced as Object3D).parent,
              originalIndex: (produced as Object3D).parent?.children.indexOf(produced as Object3D) ?? -1,
            }
            : {}),
        }
        : {
          kind: "resource",
          tag,
          resource: produced as BufferGeometry | Material,
          resourceKind: kind,
          owned,
          creationArgs: args,
          ...(typeof creationProps.attach === "string" ? { requestedAttachment: creationProps.attach } : {}),
          live: true,
        };
      if (handle.kind === "object") objectHandles.set(handle.object, handle);
      else if (owned) ownResource(handle.resource);
      handles.add(handle);
      // Resource elements attach at insertion, after their parent exists.
      void parent;
      return handle;
    },
    createText() {
      throw new Error("Three host does not support text children; use numeric or vector props instead.");
    },
    setText() {
      throw new Error("Three host does not support text children.");
    },
    setProp(handle, name, value, previous) {
      if (hostDisposed) throw new Error("Three host is disposed.");
      const eventType = eventTypeForProp(name);
      if (eventType) {
        if (handle.kind !== "object") throw new Error(`Three event ${name} requires an Object3D target.`);
        const handlers = eventHandlers.get(handle.object) ?? new Map();
        if (typeof value === "function") {
          handlers.set(eventType, value as (event: NativeThreePointerEvent) => void);
          eventHandlers.set(handle.object, handlers);
        } else {
          handlers.delete(eventType);
          if (handlers.size === 0) eventHandlers.delete(handle.object);
        }
        return;
      }
      if (handle.kind === "object" && name.startsWith("material-")) {
        const materialProperty = name.slice("material-".length);
        const pending = pendingMaterialProps.get(handle.object) ?? new Map<string, unknown>();
        if (value == null) pending.delete(materialProperty);
        else pending.set(materialProperty, value);
        pendingMaterialProps.set(handle.object, pending);
        const activeMaterial = materialFor(handle);
        if (activeMaterial === fallbackMaterial && !(materialProperty in activeMaterial)) return;
      }
      const writer = propertyWriters[name];
      if (!writer) throw new Error(`Unsupported Three native prop "${name}" on <${handle.tag}>.`);
      writer(handle, value, previous);
    },
    place(parent, handle, before) {
      if (!handle.live) throw new Error(`Cannot place disposed Three <${handle.tag}>.`);
      const target = objectForParent(parent);
      if (handle.kind === "resource") {
        attachResource(target, handle, handle.requestedAttachment);
        return;
      }
      const object = handle.object;
      target.add(object);
      const current = target.children.indexOf(object);
      if (current >= 0) target.children.splice(current, 1);
      if (before) {
        const index = before.kind === "object" ? target.children.indexOf(before.object) : -1;
        if (index >= 0) target.children.splice(index, 0, object);
        else target.children.push(object);
      } else target.children.push(object);
    },
    remove(parent, handle) {
      if (handle.kind === "resource") {
        restoreAttachment(handle);
        return;
      }
      const target = objectForParent(parent);
      if (!handle.owned && handle.originalParent) {
        restoreBorrowedObject(handle);
      } else {
        target.remove(handle.object);
      }
    },
    dispose(handle?: ThreeHandle) {
      if (handle) {
        releaseHandle(handle);
        return;
      }
      if (hostDisposed) return;
      hostDisposed = true;
      const errors: unknown[] = [];
      for (const remaining of [...handles]) {
        releaseHandle(remaining, errors);
        if (remaining.kind === "object" && (remaining.owned || !remaining.originalParent)) {
          try {
            remaining.object.parent?.remove(remaining.object);
          } catch (error) {
            errors.push(error);
          }
        }
      }
      for (const resource of [fallbackGeometry, fallbackMaterial]) {
        try {
          disposeResource(resource);
        } catch (error) {
          errors.push(error);
        }
      }
      if (errors.length) throw new AggregateError(errors, "Three host cleanup failed.");
    },
    getPublicInstance(handle) {
      return handle.kind === "object" ? handle.object : handle.resource;
    },
    dispatchPointerEvent(target, type, intersection, nativeEvent) {
      const object = target instanceof Object3D ? target : target.object;
      const handlers = eventHandlers.get(object);
      const handler = handlers?.get(type.startsWith("onPointer") ? eventTypeForProp(type) ?? type : type);
      if (!handler) return false;
      if (intersection && intersection.object !== object) {
        throw new Error("Three pointer intersection target does not match the dispatched Object3D.");
      }
      const hit = intersection ?? {
        object,
        point: object.getWorldPosition(new Vector3()),
        distance: 0,
        face: null,
        uv: undefined,
        instanceId: undefined,
      } as unknown as Intersection<Object3D>;
      handler(nativePointerEvent(type.startsWith("onPointer") ? eventTypeForProp(type)! : type, hit, nativeEvent));
      return true;
    },
  };

  return host;
}

export const dispatchThreePointerEvent = (
  host: ThreeHost,
  type: string,
  intersection: Intersection<Object3D>,
): boolean => host.dispatchPointerEvent(intersection.object, type, intersection);

export const raycastThreePointer = (
  host: ThreeHost,
  raycaster: Raycaster,
  scene: Object3D,
  type: string,
): readonly Intersection<Object3D>[] => {
  const intersections = raycaster.intersectObject(scene, true);
  for (const intersection of intersections) dispatchThreePointerEvent(host, type, intersection);
  return intersections;
};

export const createThreeNativeRoot = (
  scene: Object3D,
  options: ThreeHostOptions & { readonly rootOptions?: NativeRootOptions } = {},
) => {
  const host = createThreeHost(options);
  const root = createNativeRoot<ThreeHandle, ThreeParent>(host, scene, options.rootOptions);
  let disposed = false;
  return {
    host,
    root,
    dispose() {
      if (disposed) return;
      disposed = true;
      const errors: unknown[] = [];
      try {
        root.dispose();
      } catch (error) {
        errors.push(error);
      } finally {
        try {
          host.dispose();
        } catch (error) {
          errors.push(error);
        }
      }
      if (errors.length) throw new AggregateError(errors, "Three native root cleanup failed.");
    },
  };
};
