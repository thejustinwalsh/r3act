/** Automatic-runtime JSX ABI, kept separate from the classic native API. */
import {
  Fragment,
  jsx as classicJsx,
  type RuntimeElement,
} from "./jsx_binding_runtime.ts";

export { Fragment };

const automaticJsx = (
  type: RuntimeElement["type"],
  props: Record<string, unknown> | null,
  key?: string | number | null,
): RuntimeElement => {
  const next = { ...(props ?? {}) };
  if (key !== undefined && key !== null) next.key = key;
  return classicJsx(type, next);
};

/** Automatic JSX ABI (`jsx-runtime`). */
export const jsx = automaticJsx;
export const jsxs = automaticJsx;
export const jsxDEV = (
  type: RuntimeElement["type"],
  props: Record<string, unknown> | null,
  key?: string | number | null,
  _isStaticChildren?: boolean,
  _source?: unknown,
  _self?: unknown,
) => automaticJsx(type, props, key);
