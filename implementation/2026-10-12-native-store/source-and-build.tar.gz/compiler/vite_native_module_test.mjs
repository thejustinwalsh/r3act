import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { originalPositionFor, TraceMap } from "@jridgewell/trace-mapping";
import { nativeModuleCompilerPlugin } from "./vite_native_module.ts";

const directory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(directory, "..");
const modulePath = path.join(
  root,
  "src/browser/async_transition_stress_v1.tsx",
);
const componentModulePath = path.join(
  root,
  "src/browser/native_state_props.tsx",
);
const storeModulePath = path.join(root, "compiler/fixtures/native-store-positive.tsx");
const source = await readFile(modulePath, "utf8");
const unicodeSource = `// 🧭 native compiler source-map offset check\n${source}`;
const plugin = nativeModuleCompilerPlugin({ root });
const transform = plugin.transform;
assert.equal(typeof transform, "function");

const context = {
  addWatchFile() {},
  error(message) {
    throw new Error(String(message));
  },
};

const compile = (input) => transform.call(context, input, modulePath);

try {
  const first = await compile(unicodeSource);
  assert.ok(first?.code.includes('asyncTask("load-content", ["$request"],'));
  assert.ok(
    first.code.includes(
      'asyncTask("compose-update", ["load-content","load-target"],',
    ),
  );
  assert.ok(first.code.includes("The room stayed interactive while it worked."));
  assert.ok(first.code.includes("export const compiledAsyncTaskPlan ="));
  assert.ok(first.map);
  assert.deepEqual(first.map.sources, [modulePath]);
  assert.deepEqual(first.map.sourcesContent, [unicodeSource]);
  for (const anchor of [
    'async (values, signal) => {',
    'const request = values.get("$request")',
  ]) {
    const generatedOffset = first.code.indexOf(anchor);
    const originalOffset = unicodeSource.indexOf(anchor);
    assert.notEqual(generatedOffset, -1);
    assert.notEqual(originalOffset, -1);
    const generatedLocation = {
      line: first.code.slice(0, generatedOffset).split("\n").length,
      column: generatedOffset - first.code.lastIndexOf("\n", generatedOffset - 1) - 1,
    };
    const originalLocation = {
      line: unicodeSource.slice(0, originalOffset).split("\n").length,
      column: originalOffset - unicodeSource.lastIndexOf("\n", originalOffset - 1) - 1,
    };
    assert.deepEqual(
      originalPositionFor(new TraceMap(first.map), generatedLocation),
      { source: modulePath, line: originalLocation.line, column: originalLocation.column, name: null },
    );
  }

  const invalidRead = unicodeSource.replace(
    'const request = values.get("$request") as TransitionRequest;',
    'const inputName = "$request";\n    const request = values.get(inputName) as TransitionRequest;',
  );
  await assert.rejects(
    compile(invalidRead),
    /Native UI compilation failed.*literal.*get|Native UI compilation failed.*unsupported/i,
  );

  const second = await compile(unicodeSource);
  assert.equal(second.code, first.code);
  assert.equal(second.map.sourcesContent[0], unicodeSource);

  const componentSource = `// 🧭 component source-map offset check\n${await readFile(componentModulePath, "utf8")}`;
  const compileComponent = (input) => transform.call(context, input, componentModulePath);
  const component = await compileComponent(componentSource);
  assert.match(component.code, /compiledNativeComponentPlan/);
  assert.match(component.code, /schema_version\":2/);
  assert.match(component.code, /__nativeDefineComponent/);
  assert.match(component.code, /__nativeUseStateAt/);
  assert.match(component.code, /__nativeUseEffectAt/);
  assert.match(component.code, /__nativeBindStatePropsAt/);
  assert.match(component.code, /__nativeBindStatePropsAt\(\[/);
  assert.match(component.code, /data-x=\{__nativeBindStatePropsAt/);
  assert.match(component.code, /--dot-tint/);
  assert.match(component.code, /prop_only_sites/);
  assert.match(
    component.code,
    /"prop_only_sites":\["src\/browser\/native_state_props\.tsx#component:MovingDot#state:0","src\/browser\/native_state_props\.tsx#component:MovingDot#state:1","src\/browser\/native_state_props\.tsx#component:MovingDot#state:2"\]/,
  );
  assert.match(component.code, /compiledNativeComponentPlan\s*=\s*\{/);
  assert.match(component.code, /keyed/);
  assert.match(component.code, /<EditableRow key=\{id\}/);
  assert.match(component.code, /State branch is visible/);
  assert.match(component.code, /--dot-x/);
  assert.ok(component.map);
  assert.deepEqual(component.map.sources, [componentModulePath]);
  assert.deepEqual(component.map.sourcesContent, [componentSource]);
  const assertComponentMap = (
    generatedAnchor,
    originalAnchor = generatedAnchor,
    generatedAnchorOffset = 0,
    originalAnchorOffset = 0,
  ) => {
    const generatedOffset = component.code.indexOf(generatedAnchor) + generatedAnchorOffset;
    const originalOffset = componentSource.indexOf(originalAnchor) + originalAnchorOffset;
    assert.notEqual(generatedOffset, -1, `missing generated anchor ${generatedAnchor}`);
    assert.notEqual(originalOffset, -1, `missing source anchor ${originalAnchor}`);
    const generatedLocation = {
      line: component.code.slice(0, generatedOffset).split("\n").length,
      column: generatedOffset - component.code.lastIndexOf("\n", generatedOffset - 1) - 1,
    };
    const originalLocation = {
      line: componentSource.slice(0, originalOffset).split("\n").length,
      column: originalOffset - componentSource.lastIndexOf("\n", originalOffset - 1) - 1,
    };
    assert.deepEqual(
      originalPositionFor(new TraceMap(component.map), generatedLocation),
      { source: componentModulePath, line: originalLocation.line, column: originalLocation.column, name: null },
    );
  };
  assertComponentMap("function MovingDot");
  assertComponentMap("const animate = () =>");
  assertComponentMap("=> (x)", "data-x={x}", 4, 8);
  const storeSource = await readFile(storeModulePath, "utf8");
  const store = await transform.call(context, storeSource, storeModulePath);
  assert.ok(store?.code.includes("__nativeUseStoreAt(\"compiler/fixtures/native-store-positive.tsx#component:StorePanel#store:0\", source)"));
  assert.ok(store.code.includes("\"store_sites\":[{\"site_id\":\"compiler/fixtures/native-store-positive.tsx#component:StorePanel#store:0\",\"source_expression\":\"source\"}"));
  assert.ok(store.map);
  assert.deepEqual(store.map.sourcesContent, [storeSource]);
  const generatedStoreSource = store.code.indexOf(", source)", store.code.indexOf("__nativeUseStoreAt(\"compiler/fixtures/native-store-positive.tsx#component:StorePanel#store:0\"")) + 2;
  const originalStoreSource = storeSource.indexOf("use(source)") + "use(".length;
  const generatedStoreLocation = {
    line: store.code.slice(0, generatedStoreSource).split("\n").length,
    column: generatedStoreSource - store.code.lastIndexOf("\n", generatedStoreSource - 1) - 1,
  };
  const originalStoreLocation = {
    line: storeSource.slice(0, originalStoreSource).split("\n").length,
    column: originalStoreSource - storeSource.lastIndexOf("\n", originalStoreSource - 1) - 1,
  };
  assert.deepEqual(
    originalPositionFor(new TraceMap(store.map), generatedStoreLocation),
    { source: storeModulePath, line: originalStoreLocation.line, column: originalStoreLocation.column, name: null },
  );
  const generatedStoreCallee = store.code.indexOf("__nativeUseStoreAt(\"compiler/fixtures/native-store-positive.tsx#component:StorePanel#store:0\"");
  const originalStoreCallee = storeSource.indexOf("use(source)");
  const generatedStoreCalleeLocation = {
    line: store.code.slice(0, generatedStoreCallee).split("\n").length,
    column: generatedStoreCallee - store.code.lastIndexOf("\n", generatedStoreCallee - 1) - 1,
  };
  const originalStoreCalleeLocation = {
    line: storeSource.slice(0, originalStoreCallee).split("\n").length,
    column: originalStoreCallee - storeSource.lastIndexOf("\n", originalStoreCallee - 1) - 1,
  };
  assert.deepEqual(
    originalPositionFor(new TraceMap(store.map), generatedStoreCalleeLocation),
    { source: storeModulePath, line: originalStoreCalleeLocation.line, column: originalStoreCalleeLocation.column, name: null },
  );
  await assert.rejects(
    compileComponent(componentSource.replace(
      '  useEffect,\n  useState,',
      '  type useEffect,\n  type useState,',
    )),
    /Native UI compilation failed.*type-only|Native UI compilation failed.*type only|Native UI compilation failed.*direct named/i,
  );
  for (const [hook, typeOnlySource] of [
    ["use", `// @native-ui\nimport type { use } from "../native_runtime_api.ts";\nexport function Reader() { return <output>{String(use("key"))}</output>; }`],
    ["useStore", `// @native-ui\nimport type { useStore } from "../native_runtime_api.ts";\nexport function Reader() { return <output>{String(useStore("key"))}</output>; }`],
    ["use alias", `// @native-ui\nimport { use as read } from "../native_runtime_api.ts";\nexport function Reader() { return <output>{String(read("key"))}</output>; }`],
    ["useStore alias", `// @native-ui\nimport { useStore as read } from "../native_runtime_api.ts";\nexport function Reader() { return <output>{String(read("key"))}</output>; }`],
  ]) {
    await assert.rejects(
      transform.call(context, typeOnlySource, storeModulePath),
      /Native UI compilation failed.*direct named|Native UI compilation failed.*type-only|Native UI compilation failed.*type only/i,
      `${hook} import must be rejected when type-only or aliased`,
    );
  }
  const loopHookSource = componentSource.replace(
    "function NativeStateDemo() {",
    "function LoopHook() {\n  for (const item of [1]) useState(item);\n  return <div />;\n}\n\nfunction NativeStateDemo() {",
  );
  await assert.rejects(
    compileComponent(loopHookSource),
    /Native UI compilation failed.*loop|Native UI compilation failed.*repeated/i,
  );
  const markerWithoutNativeImports = await transform.call(
    context,
    "// @native-ui\nexport const ordinary = <div />;",
    path.join(root, "src/browser/ordinary_marker.tsx"),
  );
  assert.equal(markerWithoutNativeImports, null);
  const markerWithCommentOnlyImport = await transform.call(
    context,
    `// @native-ui\n// import { jsx, createDOMRoot } from "../native_runtime_api.ts";\nexport const ordinary = <div />;`,
    path.join(root, "src/browser/comment_import_marker.tsx"),
  );
  assert.equal(markerWithCommentOnlyImport, null);
  const typeOnlyRootImports = await transform.call(
    context,
    `// @native-ui\nimport type { createDOMRoot } from "../native_runtime_api.ts";\nexport function Statless() { return null; }`,
    path.join(root, "src/browser/type_only_native_root.tsx"),
  );
  assert.equal(typeOnlyRootImports, null);

  const statelessPath = path.join(root, "src/browser/stateless_native.tsx");
  const statelessSource = `// @native-ui
// import { useState } from "../native_runtime_api.ts"; this comment has from text
import { jsx, createDOMRoot } from "../native_runtime_api.ts";

export function StaticBadge() {
  return jsx("strong", { children: "Ready" });
}

createDOMRoot(document.querySelector("#app")!).mount(jsx(StaticBadge, {}));
`;
  const stateless = await transform.call(context, statelessSource, statelessPath);
  assert.ok(stateless?.code);
  assert.match(stateless.code, /compiledNativeComponentPlan/);
  assert.doesNotMatch(stateless.code, /compiledAsyncTaskPlan/);
  assert.match(stateless.code, /"name":"StaticBadge"/);
  assert.match(stateless.code, /"prop_only_sites":\[\]/);
  assert.match(stateless.code, /"state_sites":\[\]/);
  assert.match(stateless.code, /"effect_sites":\[\]/);
  assert.ok(stateless.map);
  assert.deepEqual(stateless.map.sources, [statelessPath]);
  assert.deepEqual(stateless.map.sourcesContent, [statelessSource]);
} finally {
  plugin.closeBundle?.call({});
}

console.log("Native Vite transform smoke passed (Unicode map, diagnostic, reuse).");
