import {
  type AnyAsyncStore,
  type StoreSource,
  StoreRenderTransaction,
} from "./async_store_runtime.ts";
import {
  type OwnerId,
  type OwnerKey,
  OwnerStateWorld,
  type StateAction,
} from "./owner_state_world.ts";
import {
  bindSources,
  type BoundValue,
  type ComponentType,
  copyKeyedOwnerMetadata,
  Fragment,
  getKeyedOwnerRegionId,
  getKeyedOwnerVersion,
  type RuntimeElement,
  type RuntimeNode,
  type ScalarSource,
} from "./jsx_binding_runtime.ts";
import {
  type RuntimeCounterCallback,
  type RuntimeProfileCallback,
  type VDOMHost,
  type VDOMKeyIndexMaintenance,
  VDOMSnapshotRoot,
} from "./vdom_snapshot_runtime.ts";
import {
  DerivedRegionDispatcher,
  type DerivedRegionGraph,
} from "./derived_region_runtime.ts";

const componentSite = Symbol("compiled-component-site");
type SiteComponent<P> = ComponentType<P> & { [componentSite]: string };
type EffectCleanup = () => void;
type EffectSetup = () => void | EffectCleanup;
type EffectRegistration = {
  owner: OwnerId;
  siteId: string;
  setup: EffectSetup;
};
type LiveEffect = { owner: OwnerId; siteId: string; cleanup?: EffectCleanup };
type PreparedRender = {
  owner: OwnerId;
  result: RuntimeNode;
  ownEffects: Map<string, EffectRegistration>;
  propBoundSites: ReadonlySet<string>;
};
type ComponentCache = {
  type: RuntimeElement["type"];
  hostKeyScope: OwnerKey;
  props: Record<string, unknown>;
  result: RuntimeNode;
  expandedResult: RuntimeNode;
  subtreeOwners: readonly OwnerId[];
  ownEffects: Map<string, EffectRegistration>;
  propBoundSites: ReadonlySet<string>;
  keyedRegion?: KeyedRegionCache;
};
type KeyedRegionCache = {
  regionId: string;
  version: object;
  componentSiteId: string;
  outputsByKey: Map<string, RuntimeNode>;
  keysByOwner: Map<OwnerId, string>;
};
export type ComponentInvalidationPlan = DerivedRegionGraph & {
  readonly region_component_site_ids: readonly string[];
};
type ActiveOwner = {
  world: OwnerStateWorld;
  owner: OwnerId;
  registerEffect: (siteId: string, setup: EffectSetup) => void;
  propBoundSites: Set<string>;
  readStore: <T>(siteId: string, source: StoreSource<T>) => T;
};
const activeOwners: ActiveOwner[] = [];

const effectKey = (owner: OwnerId, siteId: string) => `${owner}\u0000${siteId}`;

/** Attach the stable component-site ID that a compiler would emit for a function component. */
export const defineComponent = <P extends Record<string, unknown>>(
  siteId: string,
  render: ComponentType<P>,
  metadata?: { readonly propOnlySites: readonly string[] },
): ComponentType<P> => {
  if (siteId.length === 0) {
    throw new Error("Component site ID must not be empty");
  }
  Object.defineProperty(render, componentSite, { value: siteId });
  if (metadata) {
    const propOnlySites = [...metadata.propOnlySites];
    if (propOnlySites.some((site) => typeof site !== "string" || !site)) {
      throw new Error(
        "Component prop-only metadata contains an invalid state site ID",
      );
    }
    Object.defineProperty(render, componentMetadata, {
      value: Object.freeze({
        propOnlySites: Object.freeze(propOnlySites),
      }),
    });
  }
  return render;
};

const componentMetadata = Symbol("compiled-component-metadata");
type ComponentMetadata = { readonly propOnlySites: readonly string[] };

/** Build a live numeric binding from state cells owned by the active component. */
export const bindStatePropsAt = <T>(
  siteIds: readonly string[],
  derive: (values: readonly number[]) => T,
): BoundValue<T> => {
  const active = activeOwners[activeOwners.length - 1];
  if (!active) {
    throw new Error(
      "bindStatePropsAt must run while an owner-aware component is rendering",
    );
  }
  if (siteIds.length === 0 || typeof derive !== "function") {
    throw new Error("A state prop binding needs sites and a derive function");
  }
  const sources: ScalarSource[] = [];
  for (const siteId of siteIds) {
    const source = active.world.scalarSource(active.owner, siteId);
    if (!source) {
      throw new Error(`State site ${siteId} is not a numeric state cell`);
    }
    active.propBoundSites.add(siteId);
    sources.push(source);
  }
  return bindSources(sources, derive);
};

/** Explicit-site hook primitive; the compiler can lower familiar useState calls to this form. */
export const useStateAt = <T>(
  siteId: string,
  initial: T | (() => T),
): readonly [T, (action: StateAction<T>) => boolean] => {
  const active = activeOwners[activeOwners.length - 1];
  if (!active) {
    throw new Error(
      "useStateAt must run while an owner-aware component is rendering",
    );
  }
  return active.world.useState(active.owner, siteId, initial);
};

/** Register an effect by compiler site ID; setup runs after commit, cleanup on deactivation or owner removal. */
export const useEffectAt = (siteId: string, setup: EffectSetup): void => {
  const active = activeOwners[activeOwners.length - 1];
  if (!active) {
    throw new Error(
      "useEffectAt must run while an owner-aware component is rendering",
    );
  }
  active.registerEffect(siteId, setup);
};

/** Read a shared store or selector at a stable compiler-owned component site. */
export const useStoreAt = <T>(
  siteId: string,
  source: StoreSource<T>,
): T => {
  const active = activeOwners[activeOwners.length - 1];
  if (!active) {
    throw new Error(
      "useStoreAt must run while an owner-aware component is rendering",
    );
  }
  if (!siteId || !source || typeof source.read !== "function") {
    throw new Error("useStoreAt requires a site ID and store source");
  }
  return active.readStore(siteId, source);
};

export type ComponentStateRootOptions = {
  /** Defer one commit after state writes; defaults to a microtask scheduler. */
  scheduleCommit?: (commit: () => void) => void;
  /** Optional OXC-emitted state-site-to-component invalidation graph. */
  invalidationPlan?: ComponentInvalidationPlan;
  /** Optional diagnostic timing callback; not intended for production hot paths. */
  profile?: RuntimeProfileCallback;
  /** Optional diagnostic work counter callback; excludes time-only instrumentation. */
  profileCounter?: RuntimeCounterCallback;
  /** Experimental selector for comparing keyed-index algorithms in one reconciler. */
  keyIndexMaintenance?: VDOMKeyIndexMaintenance;
  /** Enable compiler-hinted same-key-set owner-cache reuse for structural commits. */
  keyedOwnerReuse?: boolean;
  /** Select the V1 checked scan or V2 trusted-token keyed-region path. */
  keyedOwnerReuseMode?: "checked" | "token";
  /** Share state/source storage with other roots in one runtime instance. */
  world?: OwnerStateWorld;
  /** Stable root namespace within a shared world. Defaults to a unique ID. */
  rootId?: string;
};

const getComponentSiteId = (type: RuntimeElement["type"]): string => {
  if (typeof type !== "function") {
    throw new Error("Expected a function component");
  }
  const siteId = (type as SiteComponent<unknown>)[componentSite];
  if (!siteId) {
    throw new Error(
      "Owner-aware components must be registered with defineComponent(siteId, render)",
    );
  }
  return siteId;
};

const keyedIdentity = (
  element: RuntimeElement,
  siteId: string,
  ordinal: number,
): OwnerKey => {
  const key = element.props.key;
  return key == null ? `@slot:${siteId}:${ordinal}` : String(key);
};

const carryHostKeys = (
  node: RuntimeNode,
  componentKey: OwnerKey,
  path = "0",
): RuntimeNode => {
  if (
    node == null || node === false || typeof node === "string" ||
    typeof node === "number"
  ) return node;
  if (Array.isArray(node)) {
    return copyKeyedOwnerMetadata(
      node,
      node.map((child, index) =>
        carryHostKeys(child, componentKey, `${path}.${index}`)
      ),
    );
  }
  if (node.type === Fragment) {
    return {
      ...node,
      props: {
        ...node.props,
        children: carryHostKeys(node.props.children, componentKey, path),
      },
    };
  }
  const existingKey = node.props.key;
  const key = existingKey == null
    ? `${String(componentKey)}:${path}`
    : String(existingKey);
  return { ...node, props: { ...node.props, key } };
};

const singleHostRootKey = (node: RuntimeNode): string | null => {
  const roots: RuntimeElement[] = [];
  const flatten = (value: RuntimeNode): boolean => {
    if (value == null || value === false) return true;
    if (Array.isArray(value)) return value.every(flatten);
    if (typeof value === "string" || typeof value === "number") return false;
    if (value.type === Fragment) return flatten(value.props.children);
    if (typeof value.type !== "string") return false;
    roots.push(value);
    return true;
  };
  if (!flatten(node) || roots.length !== 1 || roots[0].props.key == null) {
    return null;
  }
  return String(roots[0].props.key);
};

const hasNestedComponent = (node: RuntimeNode): boolean => {
  if (
    node == null || node === false || typeof node === "string" ||
    typeof node === "number"
  ) return false;
  if (Array.isArray(node)) return node.some(hasNestedComponent);
  if (typeof node.type === "function") return true;
  return hasNestedComponent(node.props.children);
};

/**
 * Small component execution bridge between owner/site state and the retained
 * VDOM. It is a runtime prototype, not the final JSX compiler output: stable
 * site IDs are supplied by `defineComponent` and `useStateAt` explicitly.
 */
export class ComponentStateRoot<H, Parent = H> {
  readonly world: OwnerStateWorld;
  readonly #rootOwner: OwnerId;
  readonly #rootId: string;
  readonly #vdom: VDOMSnapshotRoot<H, Parent>;
  #tree: RuntimeNode = null;
  #liveOwners = new Set<OwnerId>();
  #liveEffects = new Map<string, LiveEffect>();
  #liveEffectKeysByOwner = new Map<OwnerId, Set<string>>();
  #componentCache = new Map<OwnerId, ComponentCache>();
  #preparedRenders = new Map<OwnerId, PreparedRender>();
  #disposed = false;
  #scheduled = false;
  #pendingChanges = new Map<
    string,
    import("./owner_state_world.ts").StateChange
  >();
  #lastSourceValues = new Map<ScalarSource, number>();
  #liveStoreSubscriptions = new Map<AnyAsyncStore, () => void>();
  #liveStoreReaders = new Map<string, Set<AnyAsyncStore>>();
  #storeNotificationGeneration = 0;
  #committedStoreNotificationGeneration = 0;
  #sourceValueSyncVisits = 0;
  readonly #scheduleCommit: (commit: () => void) => void;
  readonly #unsubscribe: () => void;
  readonly #profile?: RuntimeProfileCallback;
  readonly #profileCounter?: RuntimeCounterCallback;
  readonly #keyedOwnerReuse: boolean;
  readonly #keyedOwnerReuseMode: "checked" | "token";
  #collectedKeyedRegions: Map<OwnerId, KeyedRegionCache> | null = null;
  #activeCounters?: Map<string, number>;
  readonly #invalidation?: {
    dispatcher: DerivedRegionDispatcher;
    sourceSlots: Map<string, number>;
    componentSites: readonly string[];
  };
  static #nextRootId = 1;

  constructor(
    host: VDOMHost<H, Parent>,
    container: Parent,
    options: ComponentStateRootOptions = {},
  ) {
    this.world = options.world ?? new OwnerStateWorld();
    this.#profile = options.profile;
    this.#profileCounter = options.profileCounter;
    this.#keyedOwnerReuse = options.keyedOwnerReuse ??
      options.keyedOwnerReuseMode !== undefined;
    this.#keyedOwnerReuseMode = options.keyedOwnerReuseMode ?? "checked";
    this.#vdom = new VDOMSnapshotRoot(
      host,
      container,
      options.profile,
      options.profileCounter
        ? (counters) => {
          for (const [name, count] of Object.entries(counters)) {
            this.#count(name, count);
          }
        }
        : undefined,
      options.keyIndexMaintenance,
    );
    const rootId = options.rootId ?? `root-${ComponentStateRoot.#nextRootId++}`;
    if (!rootId) throw new Error("Component root ID must not be empty");
    this.#rootId = rootId;
    this.#scheduleCommit = options.scheduleCommit ??
      ((commit) => queueMicrotask(commit));
    if (options.invalidationPlan) {
      const plan = options.invalidationPlan;
      if (
        plan.region_component_site_ids.some((siteId) =>
          typeof siteId !== "string" || siteId.length === 0
        )
      ) {
        throw new Error(
          "Component invalidation plan has an invalid component site ID",
        );
      }
      for (const region of plan.region_ids) {
        if (region >= plan.region_component_site_ids.length) {
          throw new Error(
            "Component invalidation region has no component site ID",
          );
        }
      }
      this.#invalidation = {
        dispatcher: new DerivedRegionDispatcher(plan),
        sourceSlots: new Map(
          plan.source_paths.map((siteId, index) => [siteId, index]),
        ),
        componentSites: plan.region_component_site_ids,
      };
    }
    this.#rootOwner = this.world.claimRootId(rootId);
    this.#unsubscribe = this.world.subscribeChanges((change) => {
      if (!this.world.isWithin(change.owner, this.#rootOwner)) return;
      this.#pendingChanges.set(`${change.owner}\u0000${change.site}`, change);
      this.#schedule();
    });
  }

  get version() {
    return this.#vdom.version;
  }

  /** Stable identifier used when coordinating transitions across native roots. */
  get rootId() {
    return this.#rootId;
  }

  get snapshot() {
    return this.#vdom.snapshot;
  }

  get partialCommitCount() {
    return this.#vdom.partialCommitCount;
  }

  get partialCommitBatchCount() {
    return this.#vdom.partialCommitBatchCount;
  }

  diagnostics() {
    return {
      version: this.version,
      ownerCount: this.#liveOwners.size,
      pendingChangeCount: this.#pendingChanges.size,
      sourceValueSyncVisits: this.#sourceValueSyncVisits,
      disposed: this.#disposed,
    };
  }

  mount(tree: RuntimeNode) {
    this.#assertActive();
    if (this.version !== 0) {
      throw new Error("ComponentStateRoot is already mounted");
    }
    this.#renderAndCommit(tree, true);
  }

  /** Commit one batched owner/site update; return false when there is no work. */
  flush(): boolean {
    this.#assertActive();
    const flushStarted = this.#profile ? performance.now() : 0;
    const reportFlush = () => {
      if (this.#activeCounters) {
        this.#profileCounter?.(Object.fromEntries(this.#activeCounters));
        this.#activeCounters = undefined;
      }
      if (this.#profile) {
        this.#profile("root.flush", performance.now() - flushStarted);
      }
    };
    this.#scheduled = false;
    const storeGeneration = this.#storeNotificationGeneration;
    const storeChangePending =
      storeGeneration !== this.#committedStoreNotificationGeneration;
    if (this.#pendingChanges.size === 0 && !storeChangePending) {
      return false;
    }
    this.#activeCounters = this.#profileCounter ? new Map() : undefined;
    const capturedChanges = [...this.#pendingChanges.values()];
    if (capturedChanges.length === 0 && !storeChangePending) return false;
    const dirtyOwners = new Set(capturedChanges.map((change) => change.owner));
    if (this.#invalidation) {
      const graphMappedOwners: OwnerId[] = [];
      for (const change of capturedChanges) {
        const sourceSlot = this.#invalidation.sourceSlots.get(change.site);
        if (sourceSlot === undefined) continue;
        this.#invalidation.dispatcher.invalidateSourceSlot(sourceSlot);
        graphMappedOwners.push(change.owner);
      }
      const affectedComponentSites = new Set<string>();
      this.#invalidation.dispatcher.flush((region) =>
        affectedComponentSites.add(this.#invalidation!.componentSites[region])
      );
      for (const owner of graphMappedOwners) {
        const cache = this.#componentCache.get(owner);
        if (
          cache &&
          !affectedComponentSites.has(
            getComponentSiteId(cache.type as RuntimeElement["type"]),
          )
        ) {
          dirtyOwners.delete(owner);
        }
      }
    }
    const directOnlyOwners = new Set<OwnerId>();
    const ownerEligibility = new Map<OwnerId, boolean>();
    for (const change of capturedChanges) {
      const cache = this.#componentCache.get(change.owner);
      const metadata = cache && (cache.type as SiteComponent<unknown> & {
        [componentMetadata]?: ComponentMetadata;
      })[componentMetadata];
      const source = this.world.scalarSource(change.owner, change.site);
      const approved = !!cache &&
        !!metadata?.propOnlySites.includes(change.site) &&
        cache.propBoundSites.has(change.site) && !!source &&
        this.#lastSourceValues.has(source);
      ownerEligibility.set(
        change.owner,
        (ownerEligibility.get(change.owner) ?? true) && approved,
      );
    }
    for (const [owner, eligible] of ownerEligibility) {
      if (eligible) {
        directOnlyOwners.add(owner);
        // A compiler-approved prop sink is itself a valid dependency even if
        // an optional component invalidation graph omits its state site.
        dirtyOwners.add(owner);
      }
    }
    const relevantOwners = new Set<OwnerId>();
    const addRelevantLineage = (owners: Iterable<OwnerId>) => {
      for (const owner of owners) {
        for (const ancestor of this.world.ownerLineage(owner)) {
          relevantOwners.add(ancestor);
        }
      }
    };
    addRelevantLineage(dirtyOwners);
    const initialDirtyOwnerIds = [...dirtyOwners];
    this.#profile?.(
      `dispatch.diagnostic.dirty-owner-count.${initialDirtyOwnerIds.length}`,
      0,
    );
    this.#profile?.(
      `dispatch.diagnostic.change-count.${capturedChanges.length}`,
      0,
    );
    if (initialDirtyOwnerIds.length !== 1) {
      this.#profile?.("dispatch.structural-gate.owner-count-not-one", 0);
    } else if (capturedChanges.length !== 1) {
      this.#profile?.("dispatch.structural-gate.change-count-not-one", 0);
    }
    const numericOnly = capturedChanges.length > 0 &&
      directOnlyOwners.size === dirtyOwners.size;
    let succeeded = false;
    if (numericOnly && !storeChangePending) {
      succeeded = this.#flushNumericSources(capturedChanges);
    }
    if (succeeded) {
      this.#finishChanges(capturedChanges);
      reportFlush();
      return true;
    }
    // Store readers need a complete candidate when local work cannot use the
    // proven numeric writer. Keep the numeric path available to mixed roots.
    if (this.#liveStoreSubscriptions.size > 0 || storeChangePending) {
      this.#renderAndCommit(this.#tree, true);
      this.#finishChanges(capturedChanges);
      reportFlush();
      return true;
    }
    // In a mixed batch, the generic candidate carries the latest numeric
    // bindings. Keep direct-only owners cached so they are not re-executed;
    // host writes happen only as part of the successful VDOM commit.
    if (directOnlyOwners.size > 0) {
      for (const owner of directOnlyOwners) dirtyOwners.delete(owner);
      relevantOwners.clear();
      addRelevantLineage(dirtyOwners);
    }
    const dirtyOwnerIds = [...dirtyOwners];
    const partialCommit =
      dirtyOwnerIds.length === 1 && capturedChanges.length === 1
        ? this.#tryPartialOwnerCommit(dirtyOwnerIds[0])
        : dirtyOwnerIds.length > 0 && directOnlyOwners.size === 0
        ? this.#tryPartialOwnerCommits(dirtyOwnerIds)
        : false;
    if (partialCommit) {
      this.#profile?.("dispatch.path.partial-owner", 0);
      this.#finishChanges(capturedChanges);
      reportFlush();
      return true;
    }
    const structuralCommit =
      dirtyOwnerIds.length === 1 && capturedChanges.length === 1 &&
        directOnlyOwners.size === 0
        ? this.#tryStructuralOwnerCommit(dirtyOwnerIds[0])
        : false;
    if (structuralCommit) {
      this.#profile?.("dispatch.path.structural-owner", 0);
      this.#finishChanges(capturedChanges);
      reportFlush();
      return true;
    }
    this.#profile?.("dispatch.path.full-reconcile", 0);
    const sourceValuesBeforeCandidate = new Map(this.#lastSourceValues);
    try {
      this.#renderAndCommit(this.#tree, false, dirtyOwners, relevantOwners);
      succeeded = true;
      if (directOnlyOwners.size > 0) {
        succeeded = this.#flushNumericSources(
          capturedChanges.filter((change) =>
            directOnlyOwners.has(change.owner)
          ),
          sourceValuesBeforeCandidate,
        ) || directOnlyOwners.size === 0;
      }
    } finally {
      this.#preparedRenders.clear();
    }
    if (succeeded) this.#finishChanges(capturedChanges);
    else this.#schedule();
    reportFlush();
    return true;
  }

  /** Replace the declarative tree while preserving component owners by site/key. */
  update(tree: RuntimeNode) {
    this.#assertActive();
    const captured = [...this.#pendingChanges.values()];
    this.#renderAndCommit(tree, true);
    this.#finishChanges(captured);
  }

  render(tree: RuntimeNode) {
    this.update(tree);
  }

  dispose() {
    if (this.#disposed) return;
    this.#disposed = true;
    this.#unsubscribe();
    this.#scheduled = false;
    this.#pendingChanges.clear();
    this.#lastSourceValues.clear();
    this.#vdom.dispose();
    const subscribedStores = [...this.#liveStoreSubscriptions.keys()];
    for (const unsubscribe of this.#liveStoreSubscriptions.values()) {
      unsubscribe();
    }
    this.#liveStoreSubscriptions.clear();
    for (const [readerId, stores] of this.#liveStoreReaders) {
      for (const store of stores) store.forgetReader(this.#rootId, readerId);
    }
    this.#liveStoreReaders.clear();
    for (const store of subscribedStores) {
      store.detachRoot(this.#rootId);
    }
    const effectErrors = this.#cleanupEffects(this.#liveEffects.values());
    this.#liveEffects.clear();
    this.#liveEffectKeysByOwner.clear();
    for (const owner of this.#liveOwners) this.world.destroyOwner(owner);
    this.#liveOwners.clear();
    this.#componentCache.clear();
    this.world.destroyOwner(this.#rootOwner);
    this.world.releaseRootId(this.#rootId, this.#rootOwner);
    if (effectErrors.length) {
      throw new AggregateError(
        effectErrors,
        "Component effect cleanup failed during dispose",
      );
    }
  }

  #renderAndCommit(
    tree: RuntimeNode,
    forceRender: boolean,
    dirtyOwners = new Set<OwnerId>(),
    relevantOwners = new Set<OwnerId>(),
  ) {
    const storeGenerationAtPrepare = this.#storeNotificationGeneration;
    const storeTransaction = new StoreRenderTransaction(this.#rootId);
    const nextOwners = new Set<OwnerId>();
    const nextEffects = new Map<string, EffectRegistration>();
    const nextComponentCache = new Map<OwnerId, ComponentCache>();
    const createdOwners: OwnerId[] = [];
    this.#collectedKeyedRegions = new Map();
    try {
      const expandStarted = this.#profile ? performance.now() : 0;
      const expanded = this.#expand(
        tree,
        this.#rootOwner,
        nextOwners,
        nextEffects,
        nextComponentCache,
        createdOwners,
        "root",
        forceRender,
        dirtyOwners,
        relevantOwners,
        [],
        new Map(),
        storeTransaction,
      );
      this.#profile?.("owner.full-expand", performance.now() - expandStarted);
      if (!storeTransaction.validate()) {
        throw new Error(
          `Store render for root ${this.#rootId} became stale during preparation`,
        );
      }
      const commitStarted = this.#profile ? performance.now() : 0;
      this.#vdom.commit(expanded);
      this.#profile?.("vdom.full-commit", performance.now() - commitStarted);
      storeTransaction.commitAfterValidatedRender();
    } catch (error) {
      storeTransaction.discard();
      this.#collectedKeyedRegions = null;
      this.#discardUncommittedStoreRoots(storeTransaction);
      // Candidate component owners are not committed; remove any newly created
      // ownership/state records so a failed render cannot leak entities.
      for (let index = createdOwners.length - 1; index >= 0; index--) {
        const owner = createdOwners[index];
        this.world.destroyOwner(owner);
        this.#dropPendingForOwner(owner);
      }
      throw error;
    }
    this.#collectedKeyedRegions = null;
    if (this.#storeNotificationGeneration === storeGenerationAtPrepare) {
      this.#committedStoreNotificationGeneration = storeGenerationAtPrepare;
    }
    this.#tree = tree;
    this.#syncStoreReaders(storeTransaction);
    const previousOwners = this.#liveOwners;
    this.#liveOwners = nextOwners;
    this.#componentCache = nextComponentCache;
    this.#syncLastSourceValues(nextComponentCache);
    const effectErrors = this.#reconcileEffects(nextEffects);
    for (const owner of previousOwners) {
      if (!nextOwners.has(owner)) {
        if (this.#activeCounters) this.#count("owner.retired");
        this.world.destroyOwner(owner);
        this.#dropPendingForOwner(owner);
      }
    }
    if (effectErrors.length) {
      throw new AggregateError(
        effectErrors,
        "Component effect setup or cleanup failed after commit",
      );
    }
  }

  #preparePartialOwnerRender(owner: OwnerId): PreparedRender | null {
    const cached = this.#componentCache.get(owner);
    if (!cached) return null;

    const ownEffects = new Map<string, EffectRegistration>();
    const propBoundSites = new Set<string>();
    const storeTransaction = new StoreRenderTransaction(this.#rootId);
    let result: RuntimeNode;
    activeOwners.push({
      world: this.world,
      owner,
      propBoundSites,
      readStore: (siteId, source) =>
        storeTransaction.read(source, `${owner}\u0000${siteId}`),
      registerEffect: (siteId, setup) => {
        if (!siteId || typeof setup !== "function") {
          throw new Error("Invalid effect registration");
        }
        const key = effectKey(owner, siteId);
        if (ownEffects.has(key)) {
          throw new Error(
            `Effect site ${siteId} was registered more than once for owner ${owner}`,
          );
        }
        ownEffects.set(key, { owner, siteId, setup });
      },
    });
    const renderStarted = this.#profile ? performance.now() : 0;
    if (this.#activeCounters) this.#count("owner.component-renders");
    try {
      result = (cached.type as (props: Record<string, unknown>) => RuntimeNode)(
        cached.props,
      );
    } catch (error) {
      storeTransaction.discard();
      this.#discardUncommittedStoreRoots(storeTransaction);
      throw error;
    } finally {
      activeOwners.pop();
    }
    if (storeTransaction.stores.size > 0) {
      storeTransaction.discard();
      this.#discardUncommittedStoreRoots(storeTransaction);
      return null;
    }
    storeTransaction.discard();
    result = carryHostKeys(result, cached.hostKeyScope);
    if (this.#profile) {
      this.#profile("owner.render-and-key", performance.now() - renderStarted);
    }
    return { owner, result, ownEffects, propBoundSites };
  }

  #commitPartialOwnerRender(prepared: PreparedRender) {
    const cached = this.#componentCache.get(prepared.owner)!;
    this.#componentCache.set(prepared.owner, {
      ...cached,
      result: prepared.result,
      expandedResult: prepared.result,
      subtreeOwners: [prepared.owner],
      ownEffects: prepared.ownEffects,
      propBoundSites: prepared.propBoundSites,
    });
    this.#syncOwnerSourceValues(
      prepared.owner,
      cached,
      prepared.propBoundSites,
    );
    this.#refreshDirectKeyedRegionOutput(prepared.owner);
    const effectErrors = this.#reconcileOwnerEffects(
      prepared.owner,
      prepared.ownEffects,
    );
    if (effectErrors.length) {
      throw new AggregateError(
        effectErrors,
        "Component effect setup or cleanup failed after partial commit",
      );
    }
  }

  #tryPartialOwnerCommit(owner: OwnerId): boolean {
    const cached = this.#componentCache.get(owner);
    if (!cached || cached.subtreeOwners.length !== 1) return false;
    const oldKey = singleHostRootKey(cached.expandedResult);
    if (oldKey === null) return false;
    const prepared = this.#preparePartialOwnerRender(owner);
    if (!prepared) return false;
    const nextKey = singleHostRootKey(prepared.result);
    if (
      !hasNestedComponent(prepared.result) && nextKey === oldKey &&
      this.#vdom.commitKeyedRegion(oldKey, prepared.result)
    ) {
      this.#commitPartialOwnerRender(prepared);
      return true;
    }
    this.#preparedRenders.set(owner, prepared);
    return false;
  }

  /**
   * Re-expand one stateful owner subtree when its keyed host root is stable.
   * Unaffected owners and effects are carried forward; keyed children inside
   * the region are reconciled by the VDOM without rerunning unchanged rows.
   */
  #tryStructuralOwnerCommit(owner: OwnerId): boolean {
    const cached = this.#componentCache.get(owner);
    if (!cached) {
      this.#profile?.("dispatch.structural-bail.cache-missing", 0);
      return false;
    }
    if (cached.subtreeOwners.length <= 1) {
      this.#profile?.("dispatch.structural-bail.no-nested-owners", 0);
      return false;
    }
    const oldKey = singleHostRootKey(cached.expandedResult);
    if (oldKey === null) {
      this.#profile?.("dispatch.structural-bail.old-root-unkeyed", 0);
      return false;
    }
    const prepared = this.#preparePartialOwnerRender(owner);
    if (!prepared) {
      this.#profile?.("dispatch.structural-bail.render-unavailable", 0);
      return false;
    }

    const nextRootKey = singleHostRootKey(prepared.result);
    if (nextRootKey !== oldKey) {
      this.#profile?.("dispatch.structural-bail.root-key-changed", 0);
      this.#preparedRenders.set(owner, prepared);
      return false;
    }

    if (this.#keyedOwnerReuse) {
      const expandStarted = this.#profile ? performance.now() : 0;
      const expandedResult = this.#expandStableKeyedOwnerResult(
        prepared.result,
        owner,
        cached,
      );
      if (this.#profile) {
        this.#profile(
          "owner.expand-and-cache",
          performance.now() - expandStarted,
        );
      }
      if (
        expandedResult !== null &&
        this.#vdom.commitKeyedRegion(oldKey, expandedResult)
      ) {
        this.#componentCache.set(owner, {
          ...cached,
          result: prepared.result,
          expandedResult,
          ownEffects: prepared.ownEffects,
          propBoundSites: prepared.propBoundSites,
        });
        this.#syncOwnerSourceValues(
          owner,
          cached,
          prepared.propBoundSites,
        );
        const effectErrors = this.#reconcileOwnerEffects(
          owner,
          prepared.ownEffects,
        );
        if (effectErrors.length) {
          throw new AggregateError(
            effectErrors,
            "Component effects failed after keyed-owner reuse commit",
          );
        }
        this.#profile?.("dispatch.path.keyed-owner-reuse", 0);
        return true;
      }
    }

    const affectedOwners = new Set(cached.subtreeOwners);
    const nextOwners = new Set<OwnerId>([owner]);
    const nextComponentCache = new Map<OwnerId, ComponentCache>();
    const nextEffects = new Map<string, EffectRegistration>();

    const createdOwners: OwnerId[] = [];
    const subtreeOwnersByOwner = new Map<OwnerId, OwnerId[]>([[owner, [
      owner,
    ]]]);
    const expandStarted = this.#profile ? performance.now() : 0;
    this.#collectedKeyedRegions = new Map();
    let structuralStoreRead = false;
    const structuralStoreTransaction = new StoreRenderTransaction(
      this.#rootId,
    );
    const expandedResult: RuntimeNode = (() => {
      try {
        for (const [key, effect] of prepared.ownEffects) {
          nextEffects.set(key, effect);
        }
        const expanded = this.#expand(
          prepared.result,
          owner,
          nextOwners,
          nextEffects,
          nextComponentCache,
          createdOwners,
          `structural/${getComponentSiteId(cached.type)}`,
          false,
          new Set(),
          new Set(),
          [owner],
          subtreeOwnersByOwner,
          structuralStoreTransaction,
        );
        if (structuralStoreTransaction.stores.size > 0) {
          structuralStoreRead = true;
          structuralStoreTransaction.discard();
          this.#discardUncommittedStoreRoots(structuralStoreTransaction);
          return null;
        }
        return expanded;
      } catch (error) {
        structuralStoreTransaction.discard();
        this.#discardUncommittedStoreRoots(structuralStoreTransaction);
        this.#collectedKeyedRegions = null;
        for (let index = createdOwners.length - 1; index >= 0; index--) {
          const owner = createdOwners[index];
          this.world.destroyOwner(owner);
          this.#dropPendingForOwner(owner);
        }
        throw error;
      }
    })();
    const structuralKeyedRegions = this.#collectedKeyedRegions;
    this.#collectedKeyedRegions = null;
    if (this.#profile) {
      this.#profile(
        "owner.expand-and-cache",
        performance.now() - expandStarted,
      );
    }
    if (structuralStoreRead) {
      for (let index = createdOwners.length - 1; index >= 0; index--) {
        const candidateOwner = createdOwners[index];
        this.world.destroyOwner(candidateOwner);
        this.#dropPendingForOwner(candidateOwner);
      }
      return false;
    }
    const ownSubtreeOwners = subtreeOwnersByOwner.get(owner) ?? [owner];
    nextComponentCache.set(owner, {
      ...cached,
      result: prepared.result,
      expandedResult,
      subtreeOwners: ownSubtreeOwners,
      ownEffects: prepared.ownEffects,
      propBoundSites: prepared.propBoundSites,
      ...(structuralKeyedRegions?.get(owner)
        ? { keyedRegion: structuralKeyedRegions.get(owner) }
        : {}),
    });

    if (!this.#vdom.commitKeyedRegion(oldKey, expandedResult)) {
      this.#profile?.("dispatch.structural-bail.keyed-region-rejected", 0);
      // Full reconciliation remains the correctness fallback. Reuse any
      // component results already produced while preparing this subtree.
      for (const candidateOwner of ownSubtreeOwners) {
        const candidate = nextComponentCache.get(candidateOwner);
        if (candidate) {
          this.#preparedRenders.set(candidateOwner, {
            owner: candidateOwner,
            result: candidate.result,
            ownEffects: candidate.ownEffects,
            propBoundSites: candidate.propBoundSites,
          });
        }
      }
      return false;
    }

    const effectErrors: unknown[] = [];
    for (const previousOwner of affectedOwners) {
      if (nextOwners.has(previousOwner)) continue;
      if (this.#activeCounters) this.#count("owner.retired");
      this.#componentCache.delete(previousOwner);
      this.#liveOwners.delete(previousOwner);
      effectErrors.push(
        ...this.#reconcileOwnerEffects(previousOwner, new Map()),
      );
      this.world.destroyOwner(previousOwner);
      this.#dropPendingForOwner(previousOwner);
    }
    for (const [nextOwner, component] of nextComponentCache) {
      this.#componentCache.set(nextOwner, component);
      this.#liveOwners.add(nextOwner);
      effectErrors.push(
        ...this.#reconcileOwnerEffects(nextOwner, component.ownEffects),
      );
    }
    this.#syncLastSourceValues(this.#componentCache);
    if (effectErrors.length) {
      throw new AggregateError(
        effectErrors,
        "Component effect setup or cleanup failed after structural commit",
      );
    }
    return true;
  }

  #expandStableKeyedOwnerResult(
    node: RuntimeNode,
    parentOwner: OwnerId,
    previousOwnerCache: ComponentCache,
  ): RuntimeNode | null {
    let regionCount = 0;
    let reusedRows = 0;
    const visit = (value: RuntimeNode): RuntimeNode | null => {
      if (
        value == null || value === false || typeof value === "string" ||
        typeof value === "number"
      ) return value;
      if (Array.isArray(value)) {
        const regionId = getKeyedOwnerRegionId(value);
        if (regionId !== null) {
          regionCount++;
          if (this.#keyedOwnerReuseMode === "token") {
            const version = getKeyedOwnerVersion(value);
            const keyedRegion = previousOwnerCache.keyedRegion;
            if (
              regionCount !== 1 || version === null || !keyedRegion ||
              keyedRegion.regionId !== regionId ||
              keyedRegion.version !== version ||
              keyedRegion.outputsByKey.size !== value.length ||
              previousOwnerCache.subtreeOwners.length !== value.length + 1
            ) {
              if (this.#activeCounters) {
                this.#count("owner.keyed-region.token-mismatches");
              }
              return null;
            }
            const output: RuntimeNode[] = [];
            for (const child of value) {
              const key = String((child as RuntimeElement).props.key);
              const cachedOutput = keyedRegion.outputsByKey.get(key);
              if (cachedOutput === undefined) return null;
              output.push(cachedOutput);
            }
            if (this.#activeCounters) {
              this.#count("owner.keyed-region.token-hits", value.length);
              this.#count(
                "owner.keyed-region.token-output-reuses",
                output.length,
              );
            }
            reusedRows += output.length;
            return copyKeyedOwnerMetadata(value, output);
          }
          if (
            regionCount !== 1 || value.length === 0 ||
            previousOwnerCache.subtreeOwners.length !== value.length + 1
          ) return null;
          const output: RuntimeNode[] = [];
          const seenKeys = new Set<string>();
          let componentSiteId: string | null = null;
          for (const child of value) {
            if (
              child == null || child === false || Array.isArray(child) ||
              typeof child !== "object" || typeof child.type !== "function"
            ) return null;
            const siteId = getComponentSiteId(child.type);
            if (
              siteId !== regionId ||
              (componentSiteId && siteId !== componentSiteId)
            ) {
              return null;
            }
            componentSiteId = siteId;
            const rawKey = child.props.key;
            if (rawKey == null) return null;
            const key = String(rawKey);
            if (seenKeys.has(key)) return null;
            seenKeys.add(key);
            const childOwner = this.world.findOwner(parentOwner, siteId, key);
            if (childOwner === undefined || !this.#liveOwners.has(childOwner)) {
              return null;
            }
            const childCache = this.#componentCache.get(childOwner);
            if (
              !childCache || childCache.type !== child.type ||
              childCache.subtreeOwners.length !== 1
            ) return null;
            const { key: _key, ref: _ref, ...props } = child.props;
            if (!shallowEqual(childCache.props, props)) return null;
            output.push(childCache.expandedResult);
            reusedRows++;
          }
          if (this.#activeCounters) {
            this.#count("owner.keyed-region.visits", value.length);
            this.#count("owner.keyed-region.eligibility-visits", value.length);
            this.#count("owner.keyed-region.cache-hits", reusedRows);
          }
          return output;
        }
        const output: RuntimeNode[] = [];
        let changed = false;
        for (const child of value) {
          const expanded = visit(child);
          if (expanded === null) return null;
          output.push(expanded);
          if (expanded !== child) changed = true;
        }
        return changed ? output : value;
      }
      if (typeof value.type === "function") return null;
      const child = visit(value.props.children);
      if (child === null) return null;
      return child === value.props.children
        ? value
        : { ...value, props: { ...value.props, children: child } };
    };
    const result = visit(node);
    if (result === null || regionCount !== 1 || reusedRows === 0) {
      this.#count("owner.keyed-region.fallback");
      return null;
    }
    return result;
  }

  #tryPartialOwnerCommits(owners: readonly OwnerId[]): boolean {
    const keys = new Map<OwnerId, string>();
    const seenKeys = new Set<string>();
    for (const owner of owners) {
      const cached = this.#componentCache.get(owner);
      if (!cached) {
        this.#profile?.("dispatch.partial-bail.cache-missing", 0);
        return false;
      }
      if (cached.subtreeOwners.length !== 1) {
        this.#profile?.("dispatch.partial-bail.owner-has-nested-subtree", 0);
        return false;
      }
      const key = singleHostRootKey(cached.expandedResult);
      if (key === null) {
        this.#profile?.("dispatch.partial-bail.old-root-unkeyed", 0);
        return false;
      }
      if (seenKeys.has(key)) {
        this.#profile?.("dispatch.partial-bail.duplicate-region-key", 0);
        return false;
      }
      seenKeys.add(key);
      keys.set(owner, key);
    }
    const prepared = owners.map((owner) =>
      this.#preparePartialOwnerRender(owner)
    );
    if (prepared.some((item) => item === null)) {
      this.#profile?.("dispatch.partial-bail.render-unavailable", 0);
      return false;
    }
    const ready = prepared as PreparedRender[];
    for (const item of ready) {
      if (
        hasNestedComponent(item.result) ||
        singleHostRootKey(item.result) !== keys.get(item.owner)
      ) {
        for (const candidate of ready) {
          this.#preparedRenders.set(candidate.owner, candidate);
        }
        this.#profile?.(
          "dispatch.partial-bail.changed-root-or-nested-owner",
          0,
        );
        return false;
      }
    }
    const regions = ready.map((item) => ({
      key: keys.get(item.owner)!,
      tree: item.result,
    }));
    if (!this.#vdom.commitKeyedRegions(regions)) {
      this.#profile?.("dispatch.partial-bail.keyed-regions-rejected", 0);
      for (const item of ready) this.#preparedRenders.set(item.owner, item);
      return false;
    }
    const effectErrors: unknown[] = [];
    for (const item of ready) {
      const cached = this.#componentCache.get(item.owner)!;
      this.#componentCache.set(item.owner, {
        ...cached,
        result: item.result,
        expandedResult: item.result,
        subtreeOwners: [item.owner],
        ownEffects: item.ownEffects,
        propBoundSites: item.propBoundSites,
      });
      this.#syncOwnerSourceValues(item.owner, cached, item.propBoundSites);
      this.#refreshDirectKeyedRegionOutput(item.owner);
      effectErrors.push(
        ...this.#reconcileOwnerEffects(item.owner, item.ownEffects),
      );
      this.#preparedRenders.delete(item.owner);
    }
    if (effectErrors.length) {
      throw new AggregateError(
        effectErrors,
        "Component effects failed after multi-region partial commit",
      );
    }
    return true;
  }

  #cleanupEffects(effects: Iterable<LiveEffect>): unknown[] {
    const errors: unknown[] = [];
    for (const effect of effects) {
      if (!effect.cleanup) continue;
      try {
        effect.cleanup();
      } catch (error) {
        errors.push(error);
      }
    }
    return errors;
  }

  #reconcileEffects(nextEffects: Map<string, EffectRegistration>): unknown[] {
    const errors = this.#cleanupEffects(
      [...this.#liveEffects].filter(([key]) => !nextEffects.has(key)).map((
        [, effect],
      ) => effect),
    );
    const nextLiveEffects = new Map<string, LiveEffect>();
    for (const [key, registration] of nextEffects) {
      const previous = this.#liveEffects.get(key);
      if (previous) {
        nextLiveEffects.set(key, previous);
        continue;
      }
      try {
        const cleanup = registration.setup();
        nextLiveEffects.set(key, {
          owner: registration.owner,
          siteId: registration.siteId,
          cleanup: typeof cleanup === "function" ? cleanup : undefined,
        });
      } catch (error) {
        errors.push(error);
        nextLiveEffects.set(key, {
          owner: registration.owner,
          siteId: registration.siteId,
        });
      }
    }
    this.#liveEffects = nextLiveEffects;
    this.#liveEffectKeysByOwner.clear();
    for (const [key, effect] of nextLiveEffects) {
      let keys = this.#liveEffectKeysByOwner.get(effect.owner);
      if (!keys) {
        this.#liveEffectKeysByOwner.set(effect.owner, keys = new Set());
      }
      keys.add(key);
    }
    return errors;
  }

  #reconcileOwnerEffects(
    owner: OwnerId,
    nextEffects: Map<string, EffectRegistration>,
  ): unknown[] {
    const errors: unknown[] = [];
    const currentKeys = this.#liveEffectKeysByOwner.get(owner);
    if (currentKeys) {
      for (const key of [...currentKeys]) {
        if (nextEffects.has(key)) continue;
        const previous = this.#liveEffects.get(key);
        if (previous?.cleanup) {
          try {
            previous.cleanup();
          } catch (error) {
            errors.push(error);
          }
        }
        this.#liveEffects.delete(key);
        currentKeys.delete(key);
      }
    }
    for (const [key, registration] of nextEffects) {
      if (this.#liveEffects.has(key)) continue;
      try {
        const cleanup = registration.setup();
        this.#liveEffects.set(key, {
          owner,
          siteId: registration.siteId,
          cleanup: typeof cleanup === "function" ? cleanup : undefined,
        });
      } catch (error) {
        errors.push(error);
        this.#liveEffects.set(key, { owner, siteId: registration.siteId });
      }
      let keys = this.#liveEffectKeysByOwner.get(owner);
      if (!keys) this.#liveEffectKeysByOwner.set(owner, keys = new Set());
      keys.add(key);
    }
    if (this.#liveEffectKeysByOwner.get(owner)?.size === 0) {
      this.#liveEffectKeysByOwner.delete(owner);
    }
    return errors;
  }

  #count(name: string, count = 1) {
    if (!this.#activeCounters || count === 0) return;
    this.#activeCounters.set(
      name,
      (this.#activeCounters.get(name) ?? 0) + count,
    );
  }

  #refreshDirectKeyedRegionOutput(owner: OwnerId) {
    const parentOwner = this.world.ownerLineage(owner)[1];
    if (parentOwner === undefined) return;
    const parentCache = this.#componentCache.get(parentOwner);
    const keyedRegion = parentCache?.keyedRegion;
    const key = keyedRegion?.keysByOwner.get(owner);
    if (key === undefined || !keyedRegion) return;
    const childCache = this.#componentCache.get(owner);
    if (childCache) {
      keyedRegion.outputsByKey.set(key, childCache.expandedResult);
    }
  }

  #schedule() {
    if (this.#disposed || this.#scheduled) return;
    this.#scheduled = true;
    this.#scheduleCommit(() => {
      if (this.#disposed || !this.#scheduled) return;
      this.#scheduled = false;
      if (
        this.#pendingChanges.size > 0 ||
        this.#storeNotificationGeneration !==
          this.#committedStoreNotificationGeneration
      ) {
        this.flush();
      }
    });
  }

  #finishChanges(
    captured: readonly import("./owner_state_world.ts").StateChange[],
  ) {
    this.world.clearChangesThrough(captured);
    for (const change of captured) {
      const key = `${change.owner}\u0000${change.site}`;
      const current = this.#pendingChanges.get(key);
      if (current && current.version <= change.version) {
        this.#pendingChanges.delete(key);
      }
    }
    if (this.#pendingChanges.size > 0) this.#schedule();
  }

  #syncStoreReaders(transaction: StoreRenderTransaction) {
    const nextReaders = new Map<string, Set<AnyAsyncStore>>();
    const nextStores = new Set<AnyAsyncStore>();
    for (const [readerId, stores] of transaction.readers) {
      const readerStores = new Set(stores);
      nextReaders.set(readerId, readerStores);
      for (const store of readerStores) nextStores.add(store);
    }
    for (const [readerId, stores] of this.#liveStoreReaders) {
      const next = nextReaders.get(readerId);
      for (const store of stores) {
        if (!next?.has(store)) store.forgetReader(this.#rootId, readerId);
      }
    }
    for (const [store, unsubscribe] of this.#liveStoreSubscriptions) {
      if (nextStores.has(store)) continue;
      unsubscribe();
      store.detachRoot(this.#rootId);
      this.#liveStoreSubscriptions.delete(store);
    }
    for (const store of nextStores) {
      if (this.#liveStoreSubscriptions.has(store)) continue;
      this.#liveStoreSubscriptions.set(
        store,
        store.subscribe(this.#rootId, () => {
          this.#storeNotificationGeneration++;
          this.#schedule();
        }),
      );
    }
    this.#liveStoreReaders = nextReaders;
  }

  #discardUncommittedStoreRoots(transaction: StoreRenderTransaction) {
    for (const store of transaction.stores) {
      if (!this.#liveStoreSubscriptions.has(store)) {
        store.detachRoot(this.#rootId);
      }
    }
  }

  #dropPendingForOwner(owner: OwnerId) {
    const prefix = `${owner}\u0000`;
    for (const key of this.#pendingChanges.keys()) {
      if (key.startsWith(prefix)) this.#pendingChanges.delete(key);
    }
  }

  #syncLastSourceValues(caches: ReadonlyMap<OwnerId, ComponentCache>) {
    const live = new Set<ScalarSource>();
    for (const [owner, cache] of caches) {
      for (const site of cache.propBoundSites) {
        this.#sourceValueSyncVisits++;
        const source = this.world.scalarSource(owner, site);
        if (!source) continue;
        live.add(source);
        this.#lastSourceValues.set(source, source.value);
      }
    }
    for (const source of this.#lastSourceValues.keys()) {
      if (!live.has(source)) this.#lastSourceValues.delete(source);
    }
  }

  #syncOwnerSourceValues(
    owner: OwnerId,
    previous: ComponentCache,
    nextSites: ReadonlySet<string>,
  ) {
    for (const site of previous.propBoundSites) {
      if (nextSites.has(site)) continue;
      const source = this.world.scalarSource(owner, site);
      if (source) this.#lastSourceValues.delete(source);
    }
    for (const site of nextSites) {
      this.#sourceValueSyncVisits++;
      const source = this.world.scalarSource(owner, site);
      if (source) this.#lastSourceValues.set(source, source.value);
    }
  }

  #flushNumericSources(
    changes: readonly import("./owner_state_world.ts").StateChange[],
    previousValues: ReadonlyMap<ScalarSource, number> = this.#lastSourceValues,
  ): boolean {
    const pending: Array<{
      source: ScalarSource;
      previous: number;
      current: number;
    }> = [];
    const seenSources = new Set<ScalarSource>();
    for (const change of changes) {
      const source = this.world.scalarSource(change.owner, change.site);
      if (!source) return false;
      const previous = previousValues.get(source);
      if (previous === undefined) return false;
      if (seenSources.has(source)) continue;
      seenSources.add(source);
      pending.push({ source, previous, current: source.value });
    }
    // Resolve every source and its prior committed value before touching any
    // shared source handle. An unavailable binding can safely take fallback.
    const updates = pending.map(({ source, current }) =>
      [source, current] as const
    );
    for (const { source, previous } of pending) source.value = previous;
    try {
      // Host writers can fail after earlier writes. Propagate that failure
      // with state pending; fallback or retry could apply a second sequence.
      const wrote = this.#vdom.setSources(updates);
      for (const { source, current } of pending) {
        this.#lastSourceValues.set(source, current);
      }
      return wrote || changes.length > 0;
    } finally {
      for (const { source, current } of pending) source.value = current;
    }
  }

  #expand(
    node: RuntimeNode,
    parentOwner: OwnerId,
    nextOwners: Set<OwnerId>,
    nextEffects: Map<string, EffectRegistration>,
    nextComponentCache: Map<OwnerId, ComponentCache>,
    createdOwners: OwnerId[],
    path: string,
    forceRender: boolean,
    dirtyOwners: Set<OwnerId>,
    relevantOwners: Set<OwnerId>,
    ownerPath: OwnerId[],
    subtreeOwnersByOwner: Map<OwnerId, OwnerId[]>,
    storeTransaction: StoreRenderTransaction,
  ): RuntimeNode {
    if (
      node == null || node === false || typeof node === "string" ||
      typeof node === "number"
    ) return node;
    if (Array.isArray(node)) {
      const regionId = getKeyedOwnerRegionId(node);
      const version = getKeyedOwnerVersion(node);
      const outputsByKey = version === null ||
          this.#keyedOwnerReuseMode !== "token"
        ? null
        : new Map<string, RuntimeNode>();
      const keysByOwner = outputsByKey ? new Map<OwnerId, string>() : null;
      let regionSiteId: string | null = null;
      let validRegion = outputsByKey !== null;
      const siteOrdinals = new Map<string, number>();
      let changed = false;
      const children = node.map((child, index) => {
        const childPath = `${path}/${index}`;
        const siteId =
          child && !Array.isArray(child) && typeof child === "object" &&
            typeof child.type === "function"
            ? getComponentSiteId(child.type)
            : "";
        const ordinal = siteId ? (siteOrdinals.get(siteId) ?? 0) : 0;
        if (siteId) siteOrdinals.set(siteId, ordinal + 1);
        const expanded = this.#expand(
          child,
          parentOwner,
          nextOwners,
          nextEffects,
          nextComponentCache,
          createdOwners,
          siteId ? `${childPath}#${ordinal}` : childPath,
          forceRender,
          dirtyOwners,
          relevantOwners,
          ownerPath,
          subtreeOwnersByOwner,
          storeTransaction,
        );
        if (expanded !== child) changed = true;
        if (outputsByKey && regionId !== null) {
          if (
            !child || Array.isArray(child) || typeof child !== "object" ||
            typeof child.type !== "function"
          ) {
            validRegion = false;
          } else {
            const childSiteId = getComponentSiteId(child.type);
            const rawKey = child.props.key;
            if (
              childSiteId !== regionId || rawKey == null ||
              (regionSiteId !== null && regionSiteId !== childSiteId)
            ) {
              validRegion = false;
            } else {
              regionSiteId = childSiteId;
              const key = String(rawKey);
              const owner = this.world.findOwner(parentOwner, childSiteId, key);
              if (outputsByKey.has(key) || owner === undefined) {
                validRegion = false;
              } else {
                outputsByKey.set(key, expanded);
                keysByOwner?.set(owner, key);
              }
            }
          }
        }
        return expanded;
      });
      if (
        validRegion && outputsByKey && regionId !== null && version !== null &&
        regionSiteId !== null && outputsByKey.size === node.length
      ) {
        this.#collectedKeyedRegions?.set(parentOwner, {
          regionId,
          version,
          componentSiteId: regionSiteId,
          outputsByKey,
          keysByOwner: keysByOwner!,
        });
      }
      return changed ? copyKeyedOwnerMetadata(node, children) : node;
    }
    if (typeof node.type === "function") {
      if (this.#activeCounters) this.#count("owner.component-visits");
      const siteId = getComponentSiteId(node.type);
      const lastSegment = path.slice(path.lastIndexOf("/") + 1);
      const ordinal = Number(lastSegment.split("#").at(-1)) || 0;
      const key = keyedIdentity(node, siteId, ordinal);
      const owner = this.world.resolveOwner(parentOwner, siteId, key);
      if (!this.#liveOwners.has(owner)) {
        createdOwners.push(owner);
        if (this.#activeCounters) this.#count("owner.created");
      }
      nextOwners.add(owner);
      if (!subtreeOwnersByOwner.has(owner)) {
        subtreeOwnersByOwner.set(owner, [owner]);
      }
      for (const ancestor of ownerPath) {
        const descendants = subtreeOwnersByOwner.get(ancestor);
        if (descendants) descendants.push(owner);
      }
      const { key: _key, ref: _ref, ...componentProps } = node.props;
      const cached = this.#componentCache.get(owner);
      const propsUnchanged = cached !== undefined &&
        shallowEqual(cached.props, componentProps);
      const shouldRender = forceRender || dirtyOwners.has(owner) || !cached ||
        cached.type !== node.type || !propsUnchanged;
      ownerPath.push(owner);
      try {
        if (!shouldRender && cached && !relevantOwners.has(owner)) {
          if (this.#activeCounters) {
            this.#count("owner.cached-reused", cached.subtreeOwners.length);
          }
          for (const cachedOwner of cached.subtreeOwners) {
            nextOwners.add(cachedOwner);
            const childCache = this.#componentCache.get(cachedOwner);
            if (!childCache) {
              throw new Error(
                `Missing component cache for owner ${cachedOwner}`,
              );
            }
            nextComponentCache.set(cachedOwner, childCache);
            for (const [registeredKey, effect] of childCache.ownEffects) {
              nextEffects.set(registeredKey, effect);
            }
            if (cachedOwner !== owner) {
              for (const ancestor of ownerPath) {
                subtreeOwnersByOwner.get(ancestor)?.push(cachedOwner);
              }
            }
          }
          return cached.expandedResult;
        }

        let result = cached?.result;
        let ownEffects = cached?.ownEffects;
        let propBoundSites: ReadonlySet<string> = cached?.propBoundSites ??
          new Set();
        if (shouldRender) {
          const prepared = this.#preparedRenders.get(owner) ?? null;
          if (prepared) {
            result = prepared.result;
            ownEffects = prepared.ownEffects;
            propBoundSites = prepared.propBoundSites;
            for (const [registeredKey, effect] of ownEffects) {
              nextEffects.set(registeredKey, effect);
            }
          } else {
            ownEffects = new Map<string, EffectRegistration>();
            const nextPropBoundSites = new Set<string>();
            propBoundSites = nextPropBoundSites;
            activeOwners.push({
              world: this.world,
              owner,
              propBoundSites: nextPropBoundSites,
              readStore: (storeSiteId, source) =>
                storeTransaction.read(
                  source,
                  `${owner}\u0000${storeSiteId}`,
                ),
              registerEffect: (effectSiteId, setup) => {
                if (effectSiteId.length === 0) {
                  throw new Error("Effect site ID must not be empty");
                }
                if (typeof setup !== "function") {
                  throw new Error("Effect setup must be a function");
                }
                const key = effectKey(owner, effectSiteId);
                if (nextEffects.has(key)) {
                  throw new Error(
                    `Effect site ${effectSiteId} was registered more than once for owner ${owner}`,
                  );
                }
                const registration = { owner, siteId: effectSiteId, setup };
                nextEffects.set(key, registration);
                ownEffects!.set(key, registration);
              },
            });
            try {
              if (this.#activeCounters) this.#count("owner.component-renders");
              result = node.type(componentProps);
            } finally {
              activeOwners.pop();
            }
            result = carryHostKeys(result, key);
          }
        } else if (ownEffects) {
          for (const [registeredKey, effect] of ownEffects) {
            nextEffects.set(registeredKey, effect);
          }
        }
        const expandedResult = this.#expand(
          result ?? null,
          owner,
          nextOwners,
          nextEffects,
          nextComponentCache,
          createdOwners,
          `${path}/${siteId}`,
          forceRender,
          dirtyOwners,
          relevantOwners,
          ownerPath,
          subtreeOwnersByOwner,
          storeTransaction,
        );
        const componentCache: ComponentCache = {
          type: node.type,
          hostKeyScope: key,
          props: componentProps,
          result: result ?? null,
          expandedResult,
          subtreeOwners: subtreeOwnersByOwner.get(owner) ?? [owner],
          ownEffects: ownEffects ?? new Map(),
          propBoundSites,
          ...(this.#collectedKeyedRegions?.get(owner)
            ? { keyedRegion: this.#collectedKeyedRegions.get(owner) }
            : {}),
        };
        nextComponentCache.set(owner, componentCache);
        return expandedResult;
      } finally {
        ownerPath.pop();
      }
    }
    const children = this.#expand(
      node.props.children,
      parentOwner,
      nextOwners,
      nextEffects,
      nextComponentCache,
      createdOwners,
      `${path}/${node.type === Fragment ? "fragment" : node.type}`,
      forceRender,
      dirtyOwners,
      relevantOwners,
      ownerPath,
      subtreeOwnersByOwner,
      storeTransaction,
    );
    return children === node.props.children
      ? node
      : { ...node, props: { ...node.props, children } };
  }

  #assertActive() {
    if (this.#disposed) throw new Error("ComponentStateRoot is disposed");
  }
}

const shallowEqual = (
  left: Record<string, unknown>,
  right: Record<string, unknown>,
) => {
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);
  if (leftKeys.length !== rightKeys.length) return false;
  for (const key of leftKeys) {
    if (!Object.hasOwn(right, key) || !Object.is(left[key], right[key])) {
      return false;
    }
  }
  return true;
};
