/** Public native author API; `jsx` uses the classic variadic factory ABI. */
import {
  bindStatePropsAt,
  type ComponentInvalidationPlan,
  ComponentStateRoot,
  type ComponentStateRootOptions,
  defineComponent,
  useEffectAt,
  useStateAt,
} from "./component_state_runtime.ts";
import {
  type ComponentType,
  Fragment,
  jsx,
  type RuntimeNode,
} from "./jsx_binding_runtime.ts";
import { DOMVDOMHost, type VDOMHost } from "./vdom_snapshot_runtime.ts";
import { OwnerStateWorld } from "./owner_state_world.ts";

export {
  bindStatePropsAt,
  defineComponent,
  Fragment,
  jsx,
  useEffectAt,
  useStateAt,
};
export { OwnerStateWorld };
export type { ComponentInvalidationPlan, ComponentStateRootOptions };

const compileRequired = (name: string): never => {
  throw new Error(
    `${name} is a native compiled hook; import it through the native JSX compiler so it can be lowered to an explicit owner/site call`,
  );
};

/** Authored hook spelling. Native modules must compile this call before execution. */
export const useState = <T>(
  _initial: T | (() => T),
): readonly [T, (action: T | ((previous: T) => T)) => boolean] =>
  compileRequired("useState");

/** Activation lifecycle hook; dependency arrays are intentionally unsupported. */
export const useEffect = (
  _setup: () => void | (() => void),
): void => compileRequired("useEffect");

export type NativeRootOptions = ComponentStateRootOptions & {
  readonly invalidationPlan?: ComponentInvalidationPlan;
};

export const createNativeRoot = <H, Parent = H>(
  host: VDOMHost<H, Parent>,
  container: Parent,
  options: NativeRootOptions = {},
) => new ComponentStateRoot(host, container, options);

export const createDOMRoot = <Parent extends Node>(
  container: Parent,
  options: NativeRootOptions = {},
) =>
  new ComponentStateRoot<Node, Parent>(new DOMVDOMHost(), container, options);

export const createWorld = () => new OwnerStateWorld();

export type { ComponentType, RuntimeNode };
