import { ScalarSource } from "./jsx_binding_runtime.ts";

/** A component instance in the owner graph. IDs are allocated once and never reused. */
export type OwnerId = number;
export type OwnerKey = string | number | null;
export type StateSiteId = string;
export type StateAction<T> = T | ((previous: T) => T);

type StateCell<T> = {
  value: T;
  version: number;
  source?: ScalarSource;
  dispatch: (action: StateAction<T>) => boolean;
};

type OwnerRecord = {
  id: OwnerId;
  parent: OwnerId | null;
  componentSiteId: string;
  key: OwnerKey;
  children: Set<OwnerId>;
};

export type StateChange = {
  owner: OwnerId;
  site: StateSiteId;
  version: number;
};

/**
 * Experimental owner-addressed hook storage.
 *
 * State is indexed by (owner entity, compiler site ID), never by call position.
 * `resolveOwner` interns a component instance by its parent, lexical component
 * site, and optional keyed-item identity. The compiler is expected to emit
 * stable site IDs; the string is explicit here so the runtime can be evaluated
 * before JSX lowering produces them.
 */
export class OwnerStateWorld {
  static #nextSourceId = 1;
  #nextOwner = 1;
  #owners = new Map<OwnerId, OwnerRecord>();
  #childrenBySlot = new Map<
    OwnerId | null,
    Map<string, Map<OwnerKey, OwnerId>>
  >();
  #stateByOwner = new Map<OwnerId, Map<StateSiteId, StateCell<unknown>>>();
  #dirtyByOwner = new Map<OwnerId, Set<StateSiteId>>();
  #changeListeners = new Set<(change: StateChange) => void>();
  #claimedRootIds = new Map<string, OwnerId>();

  claimRootId(rootId: string): OwnerId {
    if (!rootId) throw new Error("Component root ID must not be empty");
    if (this.#claimedRootIds.has(rootId)) {
      throw new Error(
        `Component root ID ${rootId} is already active in this world`,
      );
    }
    const owner = this.resolveOwner(null, `@component-root:${rootId}`);
    this.#claimedRootIds.set(rootId, owner);
    return owner;
  }

  releaseRootId(rootId: string, owner: OwnerId): void {
    if (this.#claimedRootIds.get(rootId) !== owner) return;
    this.#claimedRootIds.delete(rootId);
  }

  resolveOwner(
    parent: OwnerId | null,
    componentSiteId: string,
    key: OwnerKey = null,
  ): OwnerId {
    if (componentSiteId.length === 0) {
      throw new Error("Component site ID must not be empty");
    }
    if (parent !== null) this.#assertOwner(parent);

    let bySite = this.#childrenBySlot.get(parent);
    if (!bySite) this.#childrenBySlot.set(parent, bySite = new Map());
    let byKey = bySite.get(componentSiteId);
    if (!byKey) bySite.set(componentSiteId, byKey = new Map());
    const existing = byKey.get(key);
    if (existing !== undefined) return existing;

    const id = this.#nextOwner++;
    this.#owners.set(id, {
      id,
      parent,
      componentSiteId,
      key,
      children: new Set(),
    });
    if (parent !== null) this.#owners.get(parent)!.children.add(id);
    byKey.set(key, id);
    return id;
  }

  findOwner(
    parent: OwnerId | null,
    componentSiteId: string,
    key: OwnerKey = null,
  ): OwnerId | undefined {
    if (parent !== null) this.#assertOwner(parent);
    return this.#childrenBySlot.get(parent)?.get(componentSiteId)?.get(key);
  }

  /** React-like state API with an explicit, compiler-addressable site ID. */
  useState<T>(
    owner: OwnerId,
    site: StateSiteId,
    initial: T | (() => T),
  ): readonly [T, (action: StateAction<T>) => boolean] {
    this.#assertOwner(owner);
    if (site.length === 0) throw new Error("State site ID must not be empty");
    let sites = this.#stateByOwner.get(owner);
    if (!sites) this.#stateByOwner.set(owner, sites = new Map());
    let cell = sites.get(site) as StateCell<T> | undefined;
    if (!cell) {
      const value = typeof initial === "function"
        ? (initial as () => T)()
        : initial;
      cell = { value, version: 0, dispatch: () => false };
      if (typeof value === "number") {
        cell.source = new ScalarSource(OwnerStateWorld.#nextSourceId++, value);
      }
      cell.dispatch = (action) => {
        this.#assertOwner(owner);
        const previous = cell!.value;
        const next = typeof action === "function"
          ? (action as (previous: T) => T)(previous)
          : action;
        if (Object.is(previous, next)) return false;
        cell!.value = next;
        cell!.version++;
        // Bindings read the same cell as hooks. Mirror before notifying roots so
        // every subscriber observes a coherent value/version pair.
        if (typeof next === "number") {
          cell!.source ??= new ScalarSource(
            OwnerStateWorld.#nextSourceId++,
            next,
          );
          cell!.source.value = next;
        }
        let dirtySites = this.#dirtyByOwner.get(owner);
        if (!dirtySites) this.#dirtyByOwner.set(owner, dirtySites = new Set());
        dirtySites.add(site);
        const change = { owner, site, version: cell!.version };
        for (const listener of [...this.#changeListeners]) listener(change);
        return true;
      };
      sites.set(site, cell as StateCell<unknown>);
    }
    return [cell.value, cell.dispatch] as const;
  }

  version(owner: OwnerId, site: StateSiteId): number {
    this.#assertOwner(owner);
    return this.#stateByOwner.get(owner)?.get(site)?.version ?? 0;
  }

  /** Stable scalar handle for a numeric state cell; nonnumeric sites have none. */
  scalarSource(owner: OwnerId, site: StateSiteId): ScalarSource | null {
    this.#assertOwner(owner);
    const cell = this.#stateByOwner.get(owner)?.get(site);
    return typeof cell?.value === "number" ? cell.source ?? null : null;
  }

  /** Clear only changes at or below the captured versions. Reentrant writes survive. */
  clearChangesThrough(captured: readonly StateChange[]): void {
    for (const change of captured) {
      const sites = this.#dirtyByOwner.get(change.owner);
      if (!sites?.has(change.site)) continue;
      if (
        !this.#owners.has(change.owner) ||
        this.version(change.owner, change.site) <= change.version
      ) {
        sites.delete(change.site);
        if (sites.size === 0) this.#dirtyByOwner.delete(change.owner);
      }
    }
  }

  /** Coalesce repeated writes to the same owner/site until a scheduler consumes them. */
  pendingChanges(): StateChange[] {
    const changes: StateChange[] = [];
    for (const [owner, sites] of this.#dirtyByOwner) {
      for (const site of sites) {
        changes.push({ owner, site, version: this.version(owner, site) });
      }
    }
    return changes;
  }

  drainChanges(): StateChange[] {
    const changes = this.pendingChanges();
    this.#dirtyByOwner.clear();
    return changes;
  }

  /** Return the changed owner and its component ancestors up to the root entity. */
  ownerLineage(owner: OwnerId): OwnerId[] {
    this.#assertOwner(owner);
    const lineage: OwnerId[] = [];
    let current: OwnerId | null = owner;
    while (current !== null) {
      lineage.push(current);
      current = this.#owners.get(current)!.parent;
    }
    return lineage;
  }

  isAlive(owner: OwnerId): boolean {
    return this.#owners.has(owner);
  }

  isWithin(owner: OwnerId, ancestor: OwnerId): boolean {
    if (!this.#owners.has(owner) || !this.#owners.has(ancestor)) return false;
    let current: OwnerId | null = owner;
    while (current !== null) {
      if (current === ancestor) return true;
      current = this.#owners.get(current)!.parent;
    }
    return false;
  }

  hasPendingChanges(): boolean {
    return this.#dirtyByOwner.size !== 0;
  }

  subscribeChanges(listener: (change: StateChange) => void): () => void {
    this.#changeListeners.add(listener);
    return () => this.#changeListeners.delete(listener);
  }

  /** Destroy an owner and all nested keyed/component owners, including state traits. */
  destroyOwner(owner: OwnerId): boolean {
    const record = this.#owners.get(owner);
    if (!record) return false;
    for (const child of [...record.children]) this.destroyOwner(child);

    const bySite = this.#childrenBySlot.get(record.parent);
    const byKey = bySite?.get(record.componentSiteId);
    byKey?.delete(record.key);
    if (byKey?.size === 0) bySite?.delete(record.componentSiteId);
    if (bySite?.size === 0) this.#childrenBySlot.delete(record.parent);
    if (record.parent !== null) {
      this.#owners.get(record.parent)?.children.delete(owner);
    }

    this.#owners.delete(owner);
    this.#stateByOwner.delete(owner);
    this.#dirtyByOwner.delete(owner);
    return true;
  }

  #assertOwner(owner: OwnerId) {
    if (!this.#owners.has(owner)) {
      throw new Error(`Owner ${owner} is not alive`);
    }
  }
}
