import type { OwnerId, StateChange, StateSiteId } from "./owner_state_world.ts";

/**
 * Coalesces pending state changes by owner and state site while retaining the
 * insertion order of the first pending write to each owner/site pair.
 *
 * Keys are cached for an owner's lifetime, so setting a change does not build
 * a composite string key or allocate a per-write wrapper object.
 */
export class PendingStateChanges {
  #keysByOwner = new Map<OwnerId, Map<StateSiteId, object>>();
  #changes = new Map<object, StateChange>();

  get size(): number {
    return this.#changes.size;
  }

  set(change: StateChange): void {
    let keysBySite = this.#keysByOwner.get(change.owner);
    if (!keysBySite) {
      keysBySite = new Map();
      this.#keysByOwner.set(change.owner, keysBySite);
    }

    let key = keysBySite.get(change.site);
    if (!key) {
      key = {};
      keysBySite.set(change.site, key);
    }
    this.#changes.set(key, change);
  }

  values(): IterableIterator<StateChange> {
    return this.#changes.values();
  }

  clear(): void {
    this.#changes.clear();
    this.#keysByOwner.clear();
  }

  /** Remove captured entries that have not advanced past their captured version. */
  clearThrough(captured: readonly StateChange[]): void {
    for (const change of captured) {
      const key = this.#keysByOwner.get(change.owner)?.get(change.site);
      if (!key) continue;
      const pending = this.#changes.get(key);
      if (pending && pending.version <= change.version) this.#changes.delete(key);
    }
  }

  /** Remove an owner's pending entries and cached identities. */
  dropOwner(owner: OwnerId): void {
    const keysBySite = this.#keysByOwner.get(owner);
    if (!keysBySite) return;
    for (const key of keysBySite.values()) this.#changes.delete(key);
    this.#keysByOwner.delete(owner);
  }
}
