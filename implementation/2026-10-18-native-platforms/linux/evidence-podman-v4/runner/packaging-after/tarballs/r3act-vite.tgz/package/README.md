# @r3act/vite

Private alpha installation artifact. This package is unpublished and its namespace is not reserved. See the repository README and final master plan for the supported native TSX subset and evidence limits.

The bundled Rust/OXC compiler and the r3act-compiler-linux-arm64 executable target aarch64-unknown-linux-gnu (linux-arm64). On another platform, supply a compatible executable through nativeModulePlugin({ compilerBinary: "/path/to/compiler" }). This tarball does not provide other platform binaries.
