import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { originalPositionFor, TraceMap } from "@jridgewell/trace-mapping";
import { nativeModuleCompilerPlugin } from "./vite_native_module.ts";

const directory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(directory, "..");
const modulePath = path.join(
  root,
  "src/browser/async_transition_stress_v1.tsx",
);
const source = await readFile(modulePath, "utf8");
const unicodeSource = `// 🧭 native compiler source-map offset check\n${source}`;
const plugin = nativeModuleCompilerPlugin({ root });
const transform = plugin.transform;
assert.equal(typeof transform, "function");

const context = {
  addWatchFile() {},
  error(message) {
    throw new Error(String(message));
  },
};

const compile = (input) => transform.call(context, input, modulePath);

try {
  const first = await compile(unicodeSource);
  assert.ok(first?.code.includes('asyncTask("load-content", ["$request"],'));
  assert.ok(
    first.code.includes(
      'asyncTask("compose-update", ["load-content","load-target"],',
    ),
  );
  assert.ok(first.code.includes("The room stayed interactive while it worked."));
  assert.ok(first.code.includes("export const compiledAsyncTaskPlan ="));
  assert.ok(first.map);
  assert.deepEqual(first.map.sources, [modulePath]);
  assert.deepEqual(first.map.sourcesContent, [unicodeSource]);
  for (const anchor of [
    'async (values, signal) => {',
    'const request = values.get("$request")',
  ]) {
    const generatedOffset = first.code.indexOf(anchor);
    const originalOffset = unicodeSource.indexOf(anchor);
    assert.notEqual(generatedOffset, -1);
    assert.notEqual(originalOffset, -1);
    const generatedLocation = {
      line: first.code.slice(0, generatedOffset).split("\n").length,
      column: generatedOffset - first.code.lastIndexOf("\n", generatedOffset - 1) - 1,
    };
    const originalLocation = {
      line: unicodeSource.slice(0, originalOffset).split("\n").length,
      column: originalOffset - unicodeSource.lastIndexOf("\n", originalOffset - 1) - 1,
    };
    assert.deepEqual(
      originalPositionFor(new TraceMap(first.map), generatedLocation),
      { source: modulePath, line: originalLocation.line, column: originalLocation.column, name: null },
    );
  }

  const invalidRead = unicodeSource.replace(
    'const request = values.get("$request") as TransitionRequest;',
    'const inputName = "$request";\n    const request = values.get(inputName) as TransitionRequest;',
  );
  await assert.rejects(
    compile(invalidRead),
    /Native UI compilation failed.*literal.*get|Native UI compilation failed.*unsupported/i,
  );

  const second = await compile(unicodeSource);
  assert.equal(second.code, first.code);
  assert.equal(second.map.sourcesContent[0], unicodeSource);
} finally {
  plugin.closeBundle?.call({});
}

console.log("Native Vite transform smoke passed (Unicode map, diagnostic, reuse).");
