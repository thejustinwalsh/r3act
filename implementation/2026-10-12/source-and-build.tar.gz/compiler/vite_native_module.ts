import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";
import process from "node:process";
import MagicString from "magic-string";
import type { Plugin, ViteDevServer } from "vite";

type NativePlan = {
  schema_version: number;
  source_file: string;
  helper_module: string;
  tasks: readonly unknown[];
  task_order: readonly number[];
};

type NativeResponse = {
  id: string;
  code?: string;
  plan?: NativePlan;
  edits?: readonly NativeEdit[];
  error?: string;
};

type NativeEdit = { start: number; end: number; replacement: string };

type PendingRequest = {
  resolve: (response: NativeResponse) => void;
  reject: (error: Error) => void;
};

type NativeRequest = {
  id: string;
  path: string;
  source: string;
  helper_module: string;
};

const moduleDir = path.dirname(fileURLToPath(import.meta.url));
const defaultRoot = path.resolve(moduleDir, "..");

const helperModuleFromSource = (source: string): string => {
  for (const match of source.matchAll(
    /\bimport\s*\{([^}]+)\}\s*from\s*(["'])([^"']+)\2/g,
  )) {
    const names = match[1].split(",").map((name) => name.trim());
    if (names.includes("asyncTask")) return match[3];
  }
  return "";
};

/**
 * Compile opt-in native TSX modules with the persistent Rust/OXC process.
 * Rust owns asyncTask dependency inference; Vite continues with its usual TSX
 * and JSX lowering after the emitted source returns from this transform.
 */
export const nativeModuleCompilerPlugin = (
  options: { root?: string } = {},
): Plugin => {
  const root = path.resolve(options.root ?? defaultRoot);
  const manifestPath = path.join(root, "compiler/oxc-spike/Cargo.toml");
  const binaryPath = path.join(
    root,
    "compiler/oxc-spike/target/debug/ui-graph-compiler-spike",
  );
  let processHandle: ChildProcessWithoutNullStreams | undefined;
  let buildProcess: ChildProcessWithoutNullStreams | undefined;
  let startup: Promise<ChildProcessWithoutNullStreams> | undefined;
  let nextRequestId = 0;
  let outputBuffer = "";
  let stderrBuffer = "";
  let stopped = false;
  const pending = new Map<string, PendingRequest>();

  const failPending = (error: Error) => {
    for (const request of pending.values()) request.reject(error);
    pending.clear();
  };

  const stopCompiler = () => {
    stopped = true;
    const child = processHandle;
    const builder = buildProcess;
    processHandle = undefined;
    buildProcess = undefined;
    failPending(new Error("Native module compiler stopped"));
    child?.kill();
    builder?.kill();
  };

  const attachCompiler = (child: ChildProcessWithoutNullStreams) => {
    processHandle = child;
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", (chunk: string) => {
      outputBuffer += chunk;
      while (true) {
        const newline = outputBuffer.indexOf("\n");
        if (newline < 0) break;
        const line = outputBuffer.slice(0, newline).trim();
        outputBuffer = outputBuffer.slice(newline + 1);
        if (!line) continue;
        let response: NativeResponse;
        try {
          response = JSON.parse(line) as NativeResponse;
        } catch (error) {
          failPending(
            new Error(
              `Rust native compiler returned invalid JSON: ${String(error)}; line=${line}`,
            ),
          );
          continue;
        }
        const request = pending.get(response.id);
        if (!request) {
          failPending(
            new Error(`Rust native compiler returned unknown request ID: ${response.id}`),
          );
          continue;
        }
        pending.delete(response.id);
        request.resolve(response);
      }
    });
    child.stderr.on("data", (chunk: string) => {
      stderrBuffer = (stderrBuffer + chunk).slice(-8000);
    });
    child.on("error", (error) => {
      if (processHandle === child) processHandle = undefined;
      failPending(
        new Error(`Unable to start Rust native compiler: ${error.message}`),
      );
    });
    child.on("close", (code, signal) => {
      if (processHandle === child) {
        processHandle = undefined;
        startup = undefined;
      }
      const detail = stderrBuffer.trim();
      const error = new Error(
        `Rust native compiler exited (${code ?? signal ?? "unknown"})${detail ? `: ${detail}` : ""}`,
      );
      failPending(error);
    });
    return child;
  };

  const ensureCompiler = (): Promise<ChildProcessWithoutNullStreams> => {
    if (stopped) throw new Error("Native module compiler plugin is closed");
    if (processHandle && processHandle.exitCode === null) {
      return Promise.resolve(processHandle);
    }
    if (startup) return startup;
    outputBuffer = "";
    stderrBuffer = "";
    startup = new Promise((resolve, reject) => {
      const builder = spawn("cargo", [
        "build",
        "--quiet",
        "--manifest-path",
        manifestPath,
        "--bin",
        "ui-graph-compiler-spike",
      ], {
        cwd: root,
        env: { ...process.env, CARGO_HOME: path.join(root, ".cache/cargo") },
        stdio: ["ignore", "ignore", "pipe"],
      });
      buildProcess = builder;
      let buildErrors = "";
      builder.stderr.setEncoding("utf8");
      builder.stderr.on("data", (chunk: string) => {
        buildErrors = (buildErrors + chunk).slice(-8000);
      });
      builder.on("error", (error) => {
        buildProcess = undefined;
        startup = undefined;
        reject(new Error(`Unable to build Rust native compiler: ${error.message}`));
      });
      builder.on("close", (code, signal) => {
        if (buildProcess === builder) buildProcess = undefined;
        if (code !== 0) {
          startup = undefined;
          reject(
            new Error(
              `Rust native compiler build failed (${code ?? signal ?? "unknown"})${buildErrors ? `: ${buildErrors.trim()}` : ""}`,
            ),
          );
          return;
        }
        const child = spawn(binaryPath, ["--serve-native"], {
          cwd: root,
          stdio: ["pipe", "pipe", "pipe"],
        });
        child.on("error", (error) => {
          if (processHandle === child) processHandle = undefined;
          startup = undefined;
          reject(new Error(`Unable to start Rust native compiler: ${error.message}`));
        });
        resolve(attachCompiler(child));
      });
    });
    return startup;
  };

  const compile = async (request: Omit<NativeRequest, "id">) => {
    const child = await ensureCompiler();
    const id = `vite-native-${++nextRequestId}`;
    return await new Promise<NativeResponse>((resolve, reject) => {
      pending.set(id, { resolve, reject });
      child.stdin.write(`${JSON.stringify({ id, ...request } satisfies NativeRequest)}\n`, (error) => {
        if (!error) return;
        pending.delete(id);
        reject(new Error(`Could not send source to Rust compiler: ${error.message}`));
      });
    });
  };

  const shutdownOnServerClose = (server: ViteDevServer) => {
    server.httpServer?.once("close", stopCompiler);
    server.watcher.once("close", stopCompiler);
  };

  return {
    name: "native-module-rust-compiler",
    enforce: "pre",
    async transform(source, id) {
      const cleanId = id.split("?", 1)[0];
      if (!cleanId.endsWith(".tsx") || !source.includes("// @native-ui")) {
        return null;
      }
      const absolutePath = path.resolve(cleanId);
      const sourcePath = path.relative(root, absolutePath).split(path.sep).join("/");
      if (sourcePath.startsWith("../")) {
        this.error(`Native UI module must be inside the project root: ${cleanId}`);
      }
      const helperModule = helperModuleFromSource(source);
      if (!helperModule) {
        this.error(
          `Native UI module ${sourcePath} must import the named asyncTask helper before compilation.`,
        );
      }
      if (helperModule.startsWith(".")) {
        this.addWatchFile(path.resolve(path.dirname(absolutePath), helperModule));
      }
      const response = await compile({
        path: sourcePath,
        source,
        helper_module: helperModule,
      }).catch((error: unknown) => {
        this.error(
          `Native UI compilation failed for ${sourcePath}: ${error instanceof Error ? error.message : String(error)}`,
        );
      });
      if (response.error) {
        this.error(`Native UI compilation failed for ${sourcePath}: ${response.error}`);
      }
      if (!response.code || !response.plan) {
        this.error(
          `Native UI compiler returned an incomplete result for ${sourcePath}.`,
        );
      }
      const serializedPlan = JSON.stringify(response.plan).replace(/</g, "\\u003c");
      if (
        response.plan.schema_version !== 1 ||
        response.plan.source_file !== sourcePath ||
        response.plan.helper_module !== helperModule ||
        !Array.isArray(response.plan.tasks) ||
        !Array.isArray(response.plan.task_order) ||
        response.plan.tasks.some((task) => {
          if (!task || typeof task !== "object") return true;
          const candidate = task as Record<string, unknown>;
          return typeof candidate.id !== "string" ||
            typeof candidate.site_id !== "string" ||
            !Array.isArray(candidate.depends_on) ||
            !candidate.depends_on.every((dependency) => typeof dependency === "string");
        })
      ) {
        this.error(
          `Native UI compiler returned mismatched plan metadata for ${sourcePath}.`,
        );
      }
      if (!Array.isArray(response.edits)) {
        this.error(`Native UI compiler omitted source edits for ${sourcePath}.`);
      }
      const magic = new MagicString(source);
      let priorEnd = 0;
      let priorStart = -1;
      let firstEdit = true;
      const isCodePointBoundary = (offset: number) => {
        if (offset <= 0 || offset >= source.length) return true;
        const previous = source.charCodeAt(offset - 1);
        const current = source.charCodeAt(offset);
        return !(previous >= 0xd800 && previous <= 0xdbff && current >= 0xdc00 && current <= 0xdfff);
      };
      for (const edit of response.edits) {
        if (
          !Number.isSafeInteger(edit.start) || !Number.isSafeInteger(edit.end) ||
          edit.start < 0 || edit.end < edit.start || edit.end > source.length ||
          typeof edit.replacement !== "string" ||
          (!firstEdit && (edit.start < priorEnd || edit.start === priorStart)) ||
          !isCodePointBoundary(edit.start) || !isCodePointBoundary(edit.end)
        ) {
          this.error(
            `Native UI compiler returned malformed or overlapping source edits for ${sourcePath}.`,
          );
        }
        if (edit.start === edit.end) {
          magic.appendLeft(edit.start, edit.replacement);
        } else {
          magic.overwrite(edit.start, edit.end, edit.replacement);
        }
        priorStart = edit.start;
        priorEnd = edit.end;
        firstEdit = false;
      }
      if (magic.toString() !== response.code) {
        this.error(
          `Native UI compiler source edits did not reproduce its emitted code for ${sourcePath}.`,
        );
      }
      magic.append(`\nexport const compiledAsyncTaskPlan = ${serializedPlan} as const;\n`);
      return {
        code: magic.toString(),
        map: magic.generateMap({
          hires: true,
          includeContent: true,
          source: cleanId,
        }),
      };
    },
    configureServer: shutdownOnServerClose,
    closeBundle: stopCompiler,
  };
};
