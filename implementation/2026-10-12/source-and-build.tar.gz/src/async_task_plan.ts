import {
  type AsyncTaskSpec,
  prepareAsyncTaskPlan,
} from "./async_task_scheduler.ts";

/**
 * Authoring helper for task prerequisites. Prefix an external input ID with $
 * (for example, "$query") to declare a live input read instead of a task edge.
 * OXC infers task and external-input edges from literal `values.get("key")`
 * reads in the task callback. The two-argument form is intended for plans
 * passed through the compiler and compiled-plan binder.
 */
export const asyncTask = (
  id: string,
  dependenciesOrRun: readonly string[] | AsyncTaskSpec["run"],
  run?: AsyncTaskSpec["run"],
): AsyncTaskSpec => {
  if (typeof dependenciesOrRun === "function") {
    if (run !== undefined) {
      throw new TypeError("asyncTask received more than one callback");
    }
    return { id, dependsOn: [], run: dependenciesOrRun };
  }
  if (run === undefined) {
    throw new TypeError("asyncTask requires a callback");
  }
  return { id, dependsOn: dependenciesOrRun, run };
};

export type CompiledAsyncTaskPlan = Readonly<{
  schema_version: 1;
  source_file: string;
  tasks: readonly Readonly<{
    id: string;
    site_id: string;
    depends_on: readonly string[];
  }>[];
  task_order: readonly number[];
}>;

/**
 * Bind compiler-emitted dependency metadata to authored task implementations.
 * The plan controls the runtime edges; callbacks provide the task behavior.
 */
export const bindCompiledAsyncTasks = (
  plan: CompiledAsyncTaskPlan,
  implementations: Readonly<Record<string, AsyncTaskSpec["run"]>>,
): AsyncTaskSpec[] => {
  if (plan.schema_version !== 1) {
    throw new Error(
      `Unsupported async task plan schema: ${plan.schema_version}`,
    );
  }
  const planIds = new Set(plan.tasks.map((task) => task.id));
  if (
    planIds.size !== plan.tasks.length || plan.tasks.some((task) => !task.id)
  ) {
    throw new Error("Compiled async task IDs must be unique and non-empty");
  }
  const implementationIds = Object.keys(implementations);
  if (
    implementationIds.length !== planIds.size ||
    implementationIds.some((id) => !planIds.has(id))
  ) {
    throw new Error(
      "Async task implementations must exactly match the compiled plan",
    );
  }
  const implementationsById = plan.tasks.map((task) => {
    const run = implementations[task.id];
    if (typeof run !== "function") {
      throw new Error(`Missing async task implementation: ${task.id}`);
    }
    return {
      id: task.id,
      dependsOn: task.depends_on.map((dependency) =>
        dependency.startsWith("$") ? dependency.slice(1) : dependency
      ),
      run,
    };
  });
  const expectedOrder = plan.task_order;
  if (
    expectedOrder.length !== implementationsById.length ||
    new Set(expectedOrder).size !== implementationsById.length ||
    expectedOrder.some((task) =>
      !Number.isInteger(task) || task < 0 || task >= implementationsById.length
    )
  ) {
    throw new Error("Compiled async task order is malformed");
  }
  const rank = new Uint32Array(implementationsById.length);
  expectedOrder.forEach((task, index) => rank[task] = index);
  const indexById = new Map(plan.tasks.map((task, index) => [task.id, index]));
  for (let task = 0; task < implementationsById.length; task++) {
    for (const dependencyId of implementationsById[task].dependsOn) {
      if (
        plan.tasks[task].depends_on.some((dependency) =>
          dependency === "$" + dependencyId
        )
      ) continue;
      const dependency = indexById.get(dependencyId);
      if (dependency === undefined || rank[dependency] >= rank[task]) {
        throw new Error("Compiled async task order is not topological");
      }
    }
  }
  const tasks = expectedOrder.map((task) => implementationsById[task]);
  const inputIds = plan.tasks.flatMap((task) =>
    task.depends_on.filter((dependency) => dependency.startsWith("$")).map(
      (dependency) => dependency.slice(1),
    )
  );
  prepareAsyncTaskPlan(
    tasks,
    Object.fromEntries(inputIds.map((inputId) => [inputId, undefined])),
  );
  return tasks;
};
