import { DOMVDOMHost } from "file:///Users/tjw/Documents/Codex/2026-10-09/le/outputs/react-runtime-research/src/vdom_snapshot_runtime.ts";
globalThis.__preparedDOMHost = DOMVDOMHost;
