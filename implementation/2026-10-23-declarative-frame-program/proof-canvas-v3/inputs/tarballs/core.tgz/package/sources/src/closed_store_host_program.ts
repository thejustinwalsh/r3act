import { type ClosedNumericExpression } from "./closed_numeric_expression.ts";
import {
  closedDataArray, closedDataRecord, evaluateClosedHostValue, exactClosedFields,
  isClosedHostPrimitive, normalizeClosedHostValue,
  type ClosedHostOutputValue, type ClosedHostValue,
} from "./closed_host_value.ts";
import { evaluateClosedHostTree, normalizeClosedHostTree, type ClosedHostTreeNode } from "./closed_host_tree.ts";
import { jsx, type RuntimeElement } from "./jsx_binding_runtime.ts";
import { normalizeClosedProjectionPaths } from "./owned_store_record.ts";

type Host<Value extends ClosedHostValue> = Readonly<{
  tag: "mesh" | "group" | "div" | "span" | "output";
  key: string;
  props: readonly (readonly [string, Value])[];
  child: null;
}>;
export type ClosedStoreHostInput = Readonly<{
  storeUseSiteId: string;
  storeProp: string;
  sourceKind?: "frameClock";
  paths?: readonly (readonly string[])[];
}>;
export type ClosedStoreProjectionInput = ClosedStoreHostInput & Readonly<{
  paths: readonly (readonly string[])[];
}>;

/** Finite Store output program for keyed hosts or one retained-child wrapper. */
export type ClosedStoreHostProgram = Readonly<{
  componentProgramId: string;
  moduleRevision: string;
}> & (
  | Readonly<{ schemaVersion: 1; storeUseSiteId: string; storeProp: string; host: Host<ClosedNumericExpression> }>
  | Readonly<{ schemaVersion: 2; inputs: readonly ClosedStoreHostInput[]; host: Host<ClosedNumericExpression> }>
  | Readonly<{ schemaVersion: 3; inputs: readonly ClosedStoreHostInput[]; host: Host<ClosedHostValue> }>
  | Readonly<{ schemaVersion: 4; inputs: readonly ClosedStoreHostInput[]; host: ClosedHostTreeNode }>
  | Readonly<{ schemaVersion: 5; inputs: readonly ClosedStoreProjectionInput[]; host: ClosedHostTreeNode }>
  | Readonly<{ schemaVersion: 6; inputs: readonly ClosedStoreProjectionInput[]; host: Host<ClosedHostValue>; retainedChildProp: "children" }>
  | Readonly<{ schemaVersion: 7; inputs: readonly ClosedStoreProjectionInput[]; stateSites: readonly string[];
    effectSites: readonly string[]; host: Host<ClosedHostValue>; retainedChildProp: "children" | null }>
  | Readonly<{ schemaVersion: 8; inputs: readonly ClosedStoreProjectionInput[]; stateSites: readonly string[];
    effectSites: readonly string[]; propInputs: readonly string[];
    host: Host<ClosedHostValue>; retainedChildProp: "children" | null }>
);

export type ClosedStoreHostOutput = readonly (readonly [string, ClosedHostOutputValue])[];
const normalizedPrograms = new WeakSet<object>();

/** Check that a program came from this module's complete data normalization. */
export const isNormalizedClosedStoreHostProgram = (
  program: unknown,
): program is ClosedStoreHostProgram =>
  typeof program === "object" && program !== null && normalizedPrograms.has(program);

const ownProgram = (program: ClosedStoreHostProgram): ClosedStoreHostProgram => {
  normalizedPrograms.add(program);
  return program;
};

const record = closedDataRecord;
const exact = exactClosedFields;
const array = closedDataArray;
const allowedName = (tag: Host<ClosedHostValue>["tag"], name: string) =>
  tag === "div" || tag === "span" || tag === "output"
    ? /^data-[a-z][a-z0-9-]*$/.test(name)
    : /^(?:position|rotation|scale)-[xyz]$/.test(name) || name === "visible";
const staticThreeName = (tag: Host<ClosedHostValue>["tag"],
  name: string, expression: ClosedHostValue): boolean =>
  name !== "name" || (tag === "group" || tag === "mesh") &&
    expression.kind === "literal" && typeof expression.value === "string";
const staticThreeNamesInTree = (host: ClosedHostTreeNode): boolean =>
  host.props.every(([name, expression]) =>
    staticThreeName(host.tag, name, expression)) &&
  host.children.every((child) => child.kind !== "host" ||
    staticThreeNamesInTree(child.host));
const input = (site: unknown, prop: unknown): ClosedStoreHostInput | null =>
  typeof site === "string" && site.length > 0 &&
    typeof prop === "string" && /^[A-Za-z_$][\w$]*$/.test(prop)
    ? Object.freeze({ storeUseSiteId: site, storeProp: prop }) : null;
const directPath = normalizeClosedProjectionPaths([[]])!;

/** Copy untrusted metadata into a frozen, data-only executable plan. */
export const normalizeClosedStoreHostProgram = (
  raw: unknown,
): ClosedStoreHostProgram | null => {
  try {
    const root = record(raw);
    if (!root || typeof root.componentProgramId !== "string" ||
      !root.componentProgramId || typeof root.moduleRevision !== "string" ||
      !root.moduleRevision) return null;
    let inputs: readonly ClosedStoreHostInput[];
    let valueCount = 0;
    let stateSites: readonly string[] | undefined;
    let effectSites: readonly string[] | undefined;
    let propInputs: readonly string[] | undefined;
    if (root.schemaVersion === 1) {
      if (!exact(root, ["schemaVersion", "componentProgramId", "moduleRevision", "storeUseSiteId", "storeProp", "host"])) return null;
      const one = input(root.storeUseSiteId, root.storeProp);
      if (!one) return null;
      inputs = Object.freeze([one]);
    } else if (root.schemaVersion === 2 || root.schemaVersion === 3 || root.schemaVersion === 4 || root.schemaVersion === 5 || root.schemaVersion === 6 || root.schemaVersion === 7 || root.schemaVersion === 8) {
      if (!exact(root, root.schemaVersion === 8
        ? ["schemaVersion", "componentProgramId", "moduleRevision", "inputs", "stateSites", "effectSites", "propInputs", "host", "retainedChildProp"]
        : root.schemaVersion === 7
        ? ["schemaVersion", "componentProgramId", "moduleRevision", "inputs", "stateSites", "effectSites", "host", "retainedChildProp"]
        : root.schemaVersion === 6
        ? ["schemaVersion", "componentProgramId", "moduleRevision", "inputs", "host", "retainedChildProp"]
        : ["schemaVersion", "componentProgramId", "moduleRevision", "inputs", "host"])) return null;
      if (root.schemaVersion === 6 && root.retainedChildProp !== "children") return null;
      if (root.schemaVersion === 7 || root.schemaVersion === 8) {
        if (root.retainedChildProp !== "children" && root.retainedChildProp !== null) return null;
        const copiedStateSites = array(root.stateSites, 8);
        const copiedEffectSites = array(root.effectSites, 32);
        if (!copiedStateSites || (root.schemaVersion === 7 && copiedStateSites.length < 1) || !copiedEffectSites ||
          [...copiedStateSites, ...copiedEffectSites].some((site) =>
            typeof site !== "string" || site.length === 0) ||
          new Set(copiedStateSites).size !== copiedStateSites.length ||
          new Set(copiedEffectSites).size !== copiedEffectSites.length) return null;
        stateSites = Object.freeze(copiedStateSites as string[]);
        effectSites = Object.freeze(copiedEffectSites as string[]);
        if (root.schemaVersion === 8) {
          const copiedProps = array(root.propInputs, 8);
          if (!copiedProps || copiedProps.length < 1 || copiedProps.some((name) =>
            typeof name !== "string" || !/^[A-Za-z_$][\w$]*$/.test(name) ||
            ["key", "ref", "children", "__proto__", "prototype", "constructor"].includes(name)) ||
            new Set(copiedProps).size !== copiedProps.length) return null;
          propInputs = Object.freeze(copiedProps as string[]);
        }
      }
      const rawInputs = array(root.inputs);
      if (!rawInputs || rawInputs.length < (root.schemaVersion === 2 ? 2 : 1) || rawInputs.length > 8) return null;
      const next: ClosedStoreHostInput[] = [];
      const sites = new Set<string>();
      let hasProjection = false;
      for (const rawInput of rawInputs) {
        const item = record(rawInput);
        if (!item) return null;
        const projected = root.schemaVersion === 5 || root.schemaVersion === 6 || root.schemaVersion === 7 || root.schemaVersion === 8;
        const frameClock = Object.hasOwn(item, "sourceKind");
        if (frameClock && (!projected || item.sourceKind !== "frameClock" ||
          item.storeProp !== "$frameClock")) return null;
        if (!exact(item, ["storeUseSiteId", "storeProp",
          ...(projected ? ["paths"] : []), ...(frameClock ? ["sourceKind"] : [])])) return null;
        const lexicalInput = input(item.storeUseSiteId, item.storeProp);
        const normalized = lexicalInput && frameClock
          ? Object.freeze({ ...lexicalInput, sourceKind: "frameClock" as const })
          : lexicalInput;
        if (!normalized || sites.has(normalized.storeUseSiteId)) return null;
        sites.add(normalized.storeUseSiteId);
        if (projected) {
          const paths = normalizeClosedProjectionPaths(item.paths);
          if (!paths) return null;
          if (frameClock && paths.some((path) => path.length !== 1 ||
            !["elapsed", "delta", "timeMs", "deltaMs"].includes(path[0]))) return null;
          valueCount += paths.length;
          if (valueCount > 32) return null;
          hasProjection ||= paths.some((path) => path.length > 0);
          next.push(Object.freeze({ ...normalized, paths }));
        } else next.push(normalized);
      }
      if (root.schemaVersion === 5 && !hasProjection) return null;
      inputs = Object.freeze(next);
    } else return null;
    if ((root.schemaVersion === 7 || root.schemaVersion === 8) &&
      valueCount + stateSites!.length + (propInputs?.length ?? 0) > 32) return null;
    if (root.schemaVersion === 4 || root.schemaVersion === 5) {
      const inputCount = root.schemaVersion === 5
        ? inputs.reduce((count, item) => count + item.paths!.length, 0)
        : inputs.length;
      const host = normalizeClosedHostTree(root.host, inputCount, true,
        root.schemaVersion === 5 ? 32 : 8);
      return host && (root.schemaVersion !== 5 || staticThreeNamesInTree(host))
        ? ownProgram(Object.freeze({
        schemaVersion: root.schemaVersion,
        componentProgramId: root.componentProgramId,
        moduleRevision: root.moduleRevision,
        inputs: inputs as readonly ClosedStoreProjectionInput[],
        host,
      }) as ClosedStoreHostProgram) : null;
    }
    const host = record(root.host);
    if (!host || !exact(host, ["tag", "key", "props", "child"]) ||
      !["mesh", "group", "div", "span", "output"].includes(host.tag as string) ||
      (root.schemaVersion !== 3 && root.schemaVersion !== 6 && root.schemaVersion !== 7 && root.schemaVersion !== 8 && host.tag === "span") ||
      typeof host.key !== "string" || host.key.length === 0 ||
      host.child !== null) return null;
    const tag = host.tag as Host<ClosedHostValue>["tag"];
    const rawProps = array(host.props);
    if (!rawProps) return null;
    const props: (readonly [string, ClosedHostValue])[] = [];
    const names = new Set<string>();
    for (const rawProp of rawProps) {
      const pair = array(rawProp);
      if (!pair || pair.length !== 2 || typeof pair[0] !== "string" ||
        (root.schemaVersion !== 3 && root.schemaVersion !== 6 && root.schemaVersion !== 7 && root.schemaVersion !== 8 && !allowedName(tag, pair[0])) || names.has(pair[0])) return null;
      const expression = normalizeClosedHostValue(pair[1], tag, pair[0],
        root.schemaVersion === 6 || root.schemaVersion === 7 || root.schemaVersion === 8
          ? valueCount + (stateSites?.length ?? 0) + (propInputs?.length ?? 0)
          : inputs.length,
        root.schemaVersion === 3 || root.schemaVersion === 6 || root.schemaVersion === 7 || root.schemaVersion === 8);
      if (!expression || ((root.schemaVersion === 6 ||
        root.schemaVersion === 7 || root.schemaVersion === 8) &&
        !staticThreeName(tag, pair[0], expression))) return null;
      names.add(pair[0]);
      props.push(Object.freeze([pair[0], expression] as const));
    }
    if (props.length === 0) return null;
    const common = {
      componentProgramId: root.componentProgramId,
      moduleRevision: root.moduleRevision,
      host: Object.freeze({ tag, key: host.key, props: Object.freeze(props), child: null }),
    };
    return ownProgram(root.schemaVersion === 1
      ? Object.freeze({ ...common, schemaVersion: 1, ...inputs[0] }) as ClosedStoreHostProgram
      : Object.freeze({ ...common, schemaVersion: root.schemaVersion, inputs,
        ...(root.schemaVersion === 6 ? { retainedChildProp: "children" } : {}),
        ...(root.schemaVersion === 7 || root.schemaVersion === 8 ? {
          stateSites: stateSites!,
          effectSites: effectSites!,
          retainedChildProp: root.retainedChildProp,
        } : {}),
        ...(root.schemaVersion === 8 ? { propInputs: propInputs! } : {}),
      }) as ClosedStoreHostProgram);
  } catch {
    return null;
  }
};

/** The ordered direct Store reads covered by the frozen compiler program. */
export const closedStoreHostInputs = (
  program: ClosedStoreHostProgram,
): readonly ClosedStoreHostInput[] => program.schemaVersion !== 1
  ? program.inputs
  : Object.freeze([Object.freeze({
    storeUseSiteId: program.storeUseSiteId,
    storeProp: program.storeProp,
  })]);

/** Numeric paths for one lexical Store input; old schemas read the state directly. */
export const closedStoreHostInputPaths = (
  input: ClosedStoreHostInput,
): readonly (readonly string[])[] => input.paths ?? directPath;

/** Number of numeric expression inputs after lexical path flattening. */
export const closedStoreHostValueCount = (program: ClosedStoreHostProgram): number =>
  closedStoreHostInputs(program).reduce((count, input) =>
    count + closedStoreHostInputPaths(input).length, 0) +
  (program.schemaVersion === 7 || program.schemaVersion === 8 ? program.stateSites.length : 0) +
  (program.schemaVersion === 8 ? program.propInputs.length : 0);

/** Evaluate frozen compiler data into candidate-owned host values; unsupported values decline. */
export const evaluateClosedStoreHostProgram = (
  program: ClosedStoreHostProgram,
  numericValues: number | readonly number[],
): ClosedStoreHostOutput | null => {
  if (program.schemaVersion === 4 || program.schemaVersion === 5 ||
    program.schemaVersion === 7 || program.schemaVersion === 8) return null;
  const count = program.schemaVersion === 6 ? closedStoreHostValueCount(program)
    : program.schemaVersion !== 1 ? program.inputs.length : 1;
  const values = typeof numericValues === "number"
    ? count === 1 ? [numericValues] : null
    : array(numericValues);
  if (!values || values.length !== count || values.some((value) =>
    typeof value !== "number" || !Number.isFinite(value))) return null;
  const props: (readonly [string, ClosedHostOutputValue])[] = [];
  for (const [name, expression] of program.host.props) {
    const value = evaluateClosedHostValue(expression, values as number[]);
    if (value === undefined || (program.schemaVersion !== 3 && program.schemaVersion !== 6 && !isClosedHostPrimitive(value))) return null;
    props.push(Object.freeze([name, value] as const));
  }
  return Object.freeze(props);
};

/** Evaluate every Store schema as a keyed candidate tree for scoped host publication. */
export const evaluateClosedStoreHostTree = (
  program: ClosedStoreHostProgram,
  numericValues: number | readonly number[],
): RuntimeElement | null => {
  if (program.schemaVersion === 6) return null;
  if (program.schemaVersion !== 4 && program.schemaVersion !== 5) {
    const output = evaluateClosedStoreHostProgram(program, numericValues);
    if (!output) return null;
    const props: Record<string, unknown> = { key: program.host.key };
    for (const [name, value] of output) props[name] = value;
    return jsx(program.host.tag, props);
  }
  const count = closedStoreHostValueCount(program);
  const values = typeof numericValues === "number"
    ? count === 1 ? [numericValues] : null
    : array(numericValues);
  if (!values || values.length !== count || values.some((value) =>
    typeof value !== "number" || !Number.isFinite(value))) return null;
  return evaluateClosedHostTree(program.host, values as number[], true);
};
